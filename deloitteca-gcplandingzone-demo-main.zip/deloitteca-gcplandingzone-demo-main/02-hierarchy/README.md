# Release 1.0 | Feb 25th, 2025
## 02-hierarchy: 

This code enables quick deployment of basic GCP resources, provisioning the foundational folder and project hierarchy in addition to SA creation and API enablement. For further details please refer to this: [hierarchy](https://github.com/Deloitte-Default/deloitteca-gcplandingzone-accelerator/tree/psc-dev/hierarchy)

Functionalities that have been added to this accelerator:
1. Central Logging: A log scope is created to enable the centralized viewing of logs from multiple projects within a central logging or monitoring project. This is achieved by specifying the central project ID in the```add_to_central_logscope``` flag.
2. 2. Budgeting: A Budget can be created for a project by defining the dollar amount in the ```budget_amount``` flag
