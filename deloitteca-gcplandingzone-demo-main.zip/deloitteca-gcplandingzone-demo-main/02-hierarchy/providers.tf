terraform {
  required_providers {
    google = {
      source = "hashicorp/google"
      version = "6.21.0"
    }
  }
}

provider "google" {
  credentials = file("../keys/new/sbyprbootstrap-prj-new.json")
  }

provider "google-beta" {
  credentials = file("../keys/new/sbyprbootstrap-prj-new.json")
  }

