terraform {
  backend "gcs" {
    credentials = "../keys/new/sbyprbootstrap-prj-new.json"
    bucket = "sbyprojectfactory-bkt-new" #"sbyprojectfactory-bkt-tst"
    prefix = "terraform/demosobeys/hierarchy/state"
  }
}