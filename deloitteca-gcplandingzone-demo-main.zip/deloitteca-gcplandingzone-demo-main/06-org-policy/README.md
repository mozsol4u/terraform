# Google Cloud Organization Policy #

This module simplifies the creation and management of [organization policies]( https://cloud.google.com/resource-manager/docs/organization-policy/overview ) for your Google Cloud environment, particularly when you want to have exclusion rules. This module will allow you to set a top-level org policy and then disable it on individual projects or folders easily.

To learn more, check [this](https://github.com/terraform-google-modules/terraform-google-org-policy).

### Operational considerations ###

* The configuration consists in one or more YAML files in "configs" folder of this repository. A valid schema of the yaml is as below:

```yaml
policies:
  - constraint: "constraints/serviceuser.services"
    policy_for: "organization"
    organization_id: "40149984599"
    folder_id:
    project_id: 
    policy_type: "list"
    enforce: true
    exclude_folders: ["folders/470485585671", "folders/594740626438"]
    exclude_projects: ["hub-project-a0f1", "prd-host-project-ec94"]
  - constraint: "constraints/iam.disableServiceAccountKeyCreation"
    policy_for: organization
    organization_id: "40149984599"
    folder_id:
    project_id: 
    policy_type: "list"
    enforce: true
    exclude_folders: 
    exclude_projects: ["prd-cicd-project-5ad2"]
```
