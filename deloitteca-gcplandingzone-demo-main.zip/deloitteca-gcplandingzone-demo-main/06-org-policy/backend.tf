terraform {
  backend "gcs" {
    bucket = "sbysecurityfactory-bkt-new"
    prefix = "terraform/policy/state"
  }
}