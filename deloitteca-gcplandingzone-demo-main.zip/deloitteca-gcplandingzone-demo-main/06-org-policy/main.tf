/******************************************
  Locals configuration
 *****************************************/
locals {
 
config = [for i in fileset(path.module, "configs/*.yaml") : yamldecode(file(i))]

policies                   =  flatten([
  for i, item in local.config:[
      for pk, p in item.policies : {

          constraint       = p.constraint
          policy_for       = p.policy_for
          organization_id  = p.organization_id
          folder_id        = p.folder_id
          project_id       = p.project_id 
          policy_type      = p.policy_type
          enforce          = p.enforce
          exclude_folders  = p.exclude_folders  == null ? [] : p.exclude_folders 
          exclude_projects = p.exclude_projects == null ? [] : p.exclude_projects
          allow_list_length= p.allow_list_length == null ? 0 : p.allow_list_length
          allow            = p.allow == null ? [] : p.allow

      }
  ]
])

 }

################################################################################
#                                Policy Management                             #
################################################################################
module "org-policy" {
  source            = "./modules/terraform-google-org-policy-main"
  #version           = "~> 3.0.2"

  for_each          = {
      for p in local.policies : "${p.constraint}" => p
    }

  constraint        = lookup(each.value, "constraint")
  policy_for        = lookup(each.value, "policy_for")
  policy_type       = lookup(each.value, "policy_type")
  organization_id   = lookup(each.value, "organization_id")
  folder_id         = lookup(each.value, "folder_id")
  project_id        = lookup(each.value, "project_id")
  enforce           = lookup(each.value, "enforce")
  exclude_folders   = lookup(each.value, "exclude_folders")
  exclude_projects  = lookup(each.value, "exclude_projects")
  allow_list_length = lookup(each.value, "allow_list_length", 0)
  allow             = lookup(each.value, "allow", [])

}