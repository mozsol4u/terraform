# terraform {
#   #required_version = ">= 1.3.1"
#   required_providers {
#       google = {
#         source = "hashicorp/google"
#         version = ">= 1.3.1"
#       }
#   }
# }


terraform {
  required_providers {
    google = {
      source = "hashicorp/google"
      version = ">= 1.3.1"
    }
  }
}

provider "google" {
  credentials = file("../keys/new/sbysecurityfactory-new.json")
  }

provider "google-beta" {
  credentials = file("../keys/new/sbysecurityfactory-new.json")
  }