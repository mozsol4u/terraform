# VPC Network #

This code facilitates creating new VPC Network(s) in one or multiple GCP projects by defining your network and subnet ranges in a concise syntax.

It supports creating:

* One or multiple Google Virtual Private Network (VPC)
* Subnets within the VPC
* Secondary ranges for the subnets (if applicable)

It also makes the project a Shared VPC host via setting a flag in the configuration file.

### Operational considerations ###

* The configuration consists in one or more YAML files in "configs" folder of this repository. A valid schema of the yaml is as below:

```yaml
project-networks:
  - project_id: "nprd-host-project-f592"
    is_host: true
    networks:
      - network_name: "test"
        subnets:
          - name: "hub-subnet11-test"
            subnet_private_access: true
            region: "europe-west1"
            ip_cidr_range: "10.0.0.0/24"
            secondary_ip_ranges:
              - range_name: "pods"
                ip_cidr_range: "172.16.0.0/20"
              - range_name: "services"
                ip_cidr_range: "192.168.0.0/24"
          - name: "hub-subnet12-test"
            region: "asia-east1"   
            ip_cidr_range: "10.1.0.0/24"
            secondary_ip_ranges:
  - project_id: "prd-host-project-ec94"
    is_host: true
    networks:
      - network_name: "test22"
        subnets:
          - name: "hub-subnet21-test"
            subnet_private_access: true
            region: "europe-west1"
            ip_cidr_range: "10.0.0.0/24"
            secondary_ip_ranges:
              - range_name: "pods22"
                ip_cidr_range: "172.16.0.0/20"
              - range_name: "services22"
                ip_cidr_range: "192.168.0.0/24"
```
