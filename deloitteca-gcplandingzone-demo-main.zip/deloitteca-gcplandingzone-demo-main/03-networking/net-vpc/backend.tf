terraform {
  backend "gcs" {
    bucket = ""
    prefix = "terraform/networking/net-vpc/state"
  }
}