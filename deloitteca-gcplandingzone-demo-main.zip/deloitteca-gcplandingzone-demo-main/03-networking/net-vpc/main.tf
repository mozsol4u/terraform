/******************************************
  Locals configuration
 *****************************************/
locals {
 
config = [for i in fileset(path.module, "configs/*.yaml") : yamldecode(file(i))]

vpcs                        =  flatten([
  for i, item in local.config:[
      for pvpck, pvpc in item.project-networks : [
        for vpck, vpc in pvpc.networks : {
          vpc_project_id    = pvpc.project_id
          shared_vpc_host   = pvpc.is_host
          vpc_name          = vpc.network_name
          vpc_subnets       = [
            for subs in vpc.subnets : {
              subnet_name   = subs.name
              subnet_ip     = subs.ip_cidr_range
              subnet_region = subs.region      
            }
          ]

          secondary_ranges  = { for subs in vpc.subnets : "${subs.name}" => subs.secondary_ip_ranges if subs.secondary_ip_ranges != null }

        }
      ]
  ]
])

 }

/******************************************
  Network Creation
 *****************************************/
module "vpc" {
  source  = "terraform-google-modules/network/google"
  version = "~> 5.0"

  for_each                               = {
    for vpc in local.vpcs : "${vpc.vpc_name}/${vpc.vpc_project_id}" => vpc
  }

  project_id                             = lookup(each.value, "vpc_project_id")
  network_name                           = lookup(each.value, "vpc_name")
  delete_default_internet_gateway_routes = true

  subnets                                = lookup(each.value, "vpc_subnets")

  secondary_ranges                       = lookup(each.value, "secondary_ranges")
}



 