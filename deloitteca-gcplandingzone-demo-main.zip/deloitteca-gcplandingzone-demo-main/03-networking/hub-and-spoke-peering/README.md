# Release 1.0 | Feb 25th, 2025

Funcationalities that have been added to this accelerator:
1. Private Service Connect: It is created by specifying the psc name and psc ip address using the ```psc``` flag show below.
2. Cloud NAT

Future enhancements that need to be added to this accelerator:
1. VPC Service Controls
   
## Hub and Spoke via VPC Peering ##

This code creates a Hub and Spoke setup, where the VPC network connects satellite locations (spokes) through a single intermediary location (hub) via [VPC Peering](https://cloud.google.com/vpc/docs/vpc-peering).



### Limitations ###
Some limitations need to be taken into account when using VPC Peering, mostly due to the lack of transitivity between peerings:

* no mesh networking between the spokes
* complex support for managed services hosted in tenant VPCs connected via peering (Cloud SQL, GKE, etc.)Version
* the limit of 25 peerings in each peering group, which constrains the scalability of design

![High-level diagram](hub-and-spoke-peering.png "High-level diagram")

### Operational considerations ###

* Hub and each spoke would either use a single project or use different projects.
* A few APIs (ie. compute.googleapis.com) need to be enabled in the project, if "apply" fails due to a service not being enabled just click on the link in the error message to enable it for the project, then resume "apply".
* The configurations consists in one or more YAML files in "configs" folder of this repository. A valid schema of the yaml is as below:

```yaml
hubs:
  - hub_name: "hub-test1"
    hub_project_id: "hub-project-a0f1"
    hub_region_nat: "northamerica-northeast1"
    psc:
      - name: hub-test1-psc1
        psc_address: "10.98.250.0/24"
      - name: hub-test1-psc1
        psc_address: "10.98.249.0/24"
    hub_subnets:
      - name: "hub-subnet11-test"
        ip_cidr_range: "10.0.0.0/24"
        region: "europe-west1"
        secondary_ip_ranges:
          range_name: "t1"
          sec_ip_cidr_range: "192.168.0.0/24"
      - name: "hub-subnet12-test"
        ip_cidr_range: "10.1.0.0/24"
        region: "asia-east1"    
    spokes:
      - spoke_name: "spoke-nprd11-test"
        spoke_project_id: "nprd-host-project-f592"
        spoke_region_nat: "northamerica-northeast1"
        psc:
          - name: spoke-vpc-01-psc
            psc_address: "10.98.248.0/24"
        spoke_subnets:
          - name: "spoke-nprd11-test"
            ip_cidr_range: "10.0.16.0/24"
            region: "europe-west1"
            secondary_ip_ranges:
              range_name = "172.32.0.0/20"
              sec_ip_cidr_range = "192.169.0.0/24"  
          - name: "spoke-nprd12-test"
            ip_cidr_range: "10.1.16.0/24"
            region: "asia-northeast1"   
      - spoke_name: "spoke-prd12-test"
        spoke_project_id: "prd-host-project-ec94"
        spoke_region_nat: "northamerica-northeast1"
        psc:
        spoke_subnets:
          - name: "spoke-prd12-test"
            ip_cidr_range: "10.0.32.0/24"
            region: "us-central1"
            secondary_ip_ranges:
```
