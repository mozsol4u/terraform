/******************************************
  Locals configuration
 *****************************************/
locals {

config = [for i in fileset(path.module, "configs/*.yaml") : yamldecode(file(i))]

hubs_details                      =  flatten([
  for i, item in local.config:[
      for hk, hub in item.hubs : [
        for hkn, hubn in hub.hub_subnets : {
          hub_project_id  = hub.hub_project_id
          hub_name        = hub.hub_name
          hub_region      = hubn.region
          hub_ip_range    = hubn.ip_cidr_range
          hub_subnet_name = hubn.name
          hub_nat         = hubn.subnet_nat

        }
      ]
  ]
])


hub_psc_details                      =  flatten([
  for i, item in local.config:[
      for hk, hub in item.hubs : [
        for psck, psc in hub.psc : {
          psc_name = psc.name
          psc_address = psc.psc_address
        } 
      ] if hub.psc != null
  ]
])

hubs                      =  flatten([
  for i, item in local.config:[
      for hk, hub in item.hubs : {
              hub_project_id    = hub.hub_project_id
              hub_name          = hub.hub_name
              hub_subnets       = hub.hub_subnets
              #hub_region_nat  = hub.hub_region_nat
              hub_ip_ranges     = [
                for ip_ranges in local.hubs_details :
                  ip_ranges.hub_ip_range
              ]
              psa_config = hub.psc != null ? {
                ranges = {
                  for psc in local.hub_psc_details : psc.psc_name => psc.psc_address
                }
              }: null
              hub_secondary_ranges      = hub.hub_subnets != null ? {
                    for subs in hub.hub_subnets : "${subs.name}" => subs.secondary_ranges if subs.secondary_ranges != null
                  } : {}
            }
            
      ]
])

spokes_details                          =  flatten([
  for i, item in local.config:[
      for hk, hub in item.hubs : [
          for sk, spoke in hub.spokes : [
            for skn, spoken in spoke.spoke_subnets: {
              hub_project_id    = hub.hub_project_id
              hub_name          = hub.hub_name
              spoke_project_id  = spoke.spoke_project_id
              spoke_name        = spoke.spoke_name
              spoke_subnets     = spoke.spoke_subnets
              spoke_region      = spoken.region
              spoke_ip_range    = spoken.ip_cidr_range
              spoke_subnet_name = spoken.name
              spoke_nat         = spoken.subnet_nat
            }
          ] 
      ] if hub.spokes != null
  ]
])

spokes                          =  flatten([
  for i, item in local.config:[
      for hk, hub in item.hubs : [
          for sk, spoke in hub.spokes : {
              hub_project_id    = hub.hub_project_id
              hub_name          = hub.hub_name
              spoke_project_id  = spoke.spoke_project_id
              spoke_name        = spoke.spoke_name
              spoke_subnets     = spoke.spoke_subnets
              spoke_ip_ranges     = [
                for ip_ranges in local.spokes_details :
                  ip_ranges.spoke_ip_range
              ]
              psa_config = spoke.psc != null ? {
                ranges = {
                  for psc in spoke.psc : psc.name => psc.psc_address
                  #for psc in local.spoke_psc_details : psc.spk_psc_name => psc.spk_psc_address
                } 
              }: null
              spoke_secondary_ranges    = {
                    for subs in spoke.spoke_subnets : "${subs.name}" => subs.secondary_ranges if subs.secondary_ranges != null
                  }
              
            }
      ] if hub.spokes != null
  ]
])

 }

# ################################################################################
# #                                Hub networking                                #
# ################################################################################

module "vpc-hub" {
  source     = "./modules/net-vpc"
  for_each   = {
    for h in local.hubs : "${h.hub_name}" => h
  }
  project_id = lookup(each.value, "hub_project_id")
  name       = lookup(each.value, "hub_name")
  subnets    = lookup(each.value, "hub_subnets")
  psa_config = lookup(each.value, "psa_config")
  secondary_ranges = each.value.hub_secondary_ranges
  # psa_config  = {
  #   ranges = { myrange = "10.0.2.2/24" } # [{},{},{}]
  # }
}

data "google_compute_network" "lookup_vpc_hub_details" {
  for_each      = {
    for h in local.hubs_details : "${h.hub_subnet_name}" => h
  }
   name         = lookup(each.value, "hub_name")
   project      = lookup(each.value, "hub_project_id")
   depends_on   = [
    module.vpc-hub
  ]
}

data "google_compute_network" "lookup_vpc_hub" {
  for_each      = {
    for h in local.hubs : "${h.hub_name}" => h
  }
   name         = lookup(each.value, "hub_name")
   project      = lookup(each.value, "hub_project_id")
   depends_on   = [
    module.vpc-hub
  ]
}

module "nat-hub" {
  source         = "./modules/net-cloudnat"
  for_each   = {
    for h in local.hubs_details : "${h.hub_subnet_name}" => h if h.hub_nat != false
  }
  project_id     = each.value.hub_project_id 
  region         = each.value.hub_region 
  name           = "natgtwy-${each.value.hub_name}-${each.value.hub_subnet_name}" 
  router_name    = "${each.value.hub_name}-natrouter"
  router_network = module.vpc-hub["${each.value.hub_name}"].name
  config_source_subnets = "LIST_OF_SUBNETWORKS"
  subnetworks = [
      {
      self_link            = each.value.hub_subnet_name
      config_source_ranges = ["PRIMARY_IP_RANGE"]
      secondary_ranges     = []
    }
  ]
  depends_on   = [
    module.vpc-hub
  ]
}

module "vpc-hub-firewall" {
  source     = "./modules/net-vpc-firewall"
  for_each   = {
    for h in local.hubs : "${h.hub_name}" => h
  }
  project_id = lookup(each.value, "hub_project_id")
  network    = data.google_compute_network.lookup_vpc_hub[lookup(each.value, "hub_name")].name
  default_rules_config = {
    admin_ranges = lookup(each.value, "hub_ip_ranges")
  }
}

# # ################################################################################
# # #                              Spokes networking                               #
# # ################################################################################

module "vpc-spoke" {
  source     = "./modules/net-vpc"
  for_each   = {
    for s in local.spokes : "${s.spoke_name}" => s
  }
  project_id = lookup(each.value, "spoke_project_id")
  name       = lookup(each.value, "spoke_name")
  subnets    = lookup(each.value, "spoke_subnets")
  psa_config = lookup(each.value, "psa_config")
  secondary_ranges = each.value.spoke_secondary_ranges

}

data "google_compute_network" "lookup_vpc_spokes_details" {
  for_each      = {
    for s in local.spokes_details : "${s.spoke_subnet_name}" => s
  }
   name         = lookup(each.value, "spoke_name")
   project      = lookup(each.value, "spoke_project_id")
   depends_on   = [
    module.vpc-spoke
  ]
}

data "google_compute_network" "lookup_vpc_spokes" {
  for_each      = {
    for s in local.spokes : "${s.spoke_name}" => s
  }
   name         = lookup(each.value, "spoke_name")
   project      = lookup(each.value, "spoke_project_id")
   depends_on   = [
    module.vpc-spoke
  ]
}

 module "nat-spoke" {
   source         = "./modules/net-cloudnat"
   for_each   = {
     for s in local.spokes_details : "${s.spoke_subnet_name}" => s if s.spoke_nat != false
   }
   project_id     = each.value.spoke_project_id 
   region         = each.value.spoke_region
   name           = "natgtwy-${each.value.spoke_name}-${each.value.spoke_subnet_name}" 
   router_name    = "${each.value.spoke_name}-natrouter"
   router_network = module.vpc-spoke["${each.value.spoke_name}"].name
   config_source_subnets = "LIST_OF_SUBNETWORKS"
    subnetworks = [
        {
        self_link            = each.value.spoke_subnet_name
        config_source_ranges = ["PRIMARY_IP_RANGE"]
        secondary_ranges     = []
      }
    ]
   depends_on   = [
    module.vpc-spoke
  ]
 }

module "vpc-spoke-firewall" {
  source     = "./modules/net-vpc-firewall"
  for_each   = {
    for s in local.spokes : "${s.spoke_name}" => s
  }
  project_id = lookup(each.value, "spoke_project_id")
  network    = data.google_compute_network.lookup_vpc_spokes[lookup(each.value, "spoke_name")].name
  default_rules_config = {
    admin_ranges = lookup(each.value, "spoke_ip_ranges")
  }
}

# # ################################################################################
# # #                              Peering                                         #
# # ################################################################################

module "hub-to-spoke-peering" {
  source                     = "./modules/net-vpc-peering"
  for_each   = {
    for s in local.spokes : "${s.spoke_name}" => s
  }
  local_network              = module.vpc-hub["${each.value.hub_name}"].self_link #data.google_compute_network.lookup_vpc_hub[lookup(each.value, "hub_name")].id
  peer_network               = module.vpc-spoke["${each.value.spoke_name}"].self_link #data.google_compute_network.lookup_vpc_spokes[lookup(each.value, "spoke_name")].id
  export_local_custom_routes = true
  export_peer_custom_routes  = false
}