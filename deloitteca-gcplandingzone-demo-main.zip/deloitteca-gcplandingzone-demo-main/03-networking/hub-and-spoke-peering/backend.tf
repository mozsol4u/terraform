terraform {
  backend "gcs" {
    credentials = "../../keys/sbynpsharedsvcsntw-prj-tst.json"
    bucket = "sbynpsharedsvcstfntw-bkt-tst" 
    prefix = "terraform/demosobeys/networking/state"
  }
}