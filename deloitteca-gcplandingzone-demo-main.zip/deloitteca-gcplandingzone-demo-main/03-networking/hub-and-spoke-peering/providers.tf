# terraform {
#   required_providers {
#     google = {
#       source = "hashicorp/google"
#       version = "4.46.0"
#     }
#   }
# }

# provider "google" {
#   # Configuration options
# }

# terraform {
#   required_version = ">= 1.3.1"
#   required_providers {
#     google = {
#       source  = "hashicorp/google"
#       version = ">= 4.50.0" # tftest
#       credentials = file("networkingproj101-0e59-72391731e886.json")
#     }
#     google-beta = {
#       source  = "hashicorp/google-beta"
#       version = ">= 4.50.0" # tftest
#       credentials = file("networkingproj101-0e59-72391731e886.json")
#     }
#   }
# }

terraform {
  required_providers {
    google = {
      source = "hashicorp/google"
      version = "~> 4.50.0"
    }
  }
}

provider "google" {
  credentials = file("../../keys/sbynpsharedsvcsntw-prj-tst.json")
  }

provider "google-beta" {
  credentials = file("../../keys/sbynpsharedsvcsntw-prj-tst.json")
  }