# README #

This README would normally document whatever steps are necessary to get your configuration running.

## What is this repository for? ##

This Code is designed to have VPN connectivity between multiple networks

## Folder Definitions ##
vpn: it consists of code to deploy vpn 


modules: it consists of google fabric's "net-vpn-static" module

## How To Run Code ##

cd vpn/

place your input yamls files under "yaml" folder

## Prerequiste ##

VPC networks and Subnets should exists beforehand, code is designed to create VPN connection between pre-existing Networks only


update  *Provider.tf and Backend.tf* for setting the following variables:

***Provider.tf: define your credentials here for authentication with GCP***

***backend.tf: define cloud storage bucket to keep tfstate files ***

#### Yaml File Breakdown ####

To create VPN connectivity , yaml file Should have a block name ***vpn*** which can consist of list of elements each representing a new vpn gateway and tunnel configuration required for vpn


#### Input Parameters ####

|name|description|required|default|
|:----|:----|:----|:----|
|name|VPN gateway name, and prefix used for dependent resources.|Yes| |
|network|VPC used for the gateway and routes.|Yes| |
|project_id|Project where resources will be created.|Yes| |
|region|Region used for resources.|Yes| |
|remote_ranges|Remote IP CIDR ranges.|Yes|[]|
|tunnels|VPN tunnel configurations.|Yes|{}|
| |name : name of tunnel|Yes| |
| |dest_range : cidr range of destination netowork|Yes| |
| |peer_gw : destination  gateway name|Yes| |
| |local_traffic_selector : defines the set of local IP ranges (CIDR blocks) from the perspective of the VPN gateway that emits the VPN tunnel|Yes| |
| |remote_traffic_selector : defines the set of remote IP ranges (CIDR blocks) from the perspective of the VPN gateway that emits the VPN tunnel|Yes| |
| |shared_secret : shared secret string for tunnel connectivity|Yes| |
| |ike_version: ike version|No|2|
| |priority: route priority|No|1000|




***Note*** : At least two cross referencing configurations are required to make VPN connection from both end. 
