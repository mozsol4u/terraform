terraform {
  required_version = ">= 0.12"
}

provider "google" {
  credentials = file("credential__json_file")
  }








