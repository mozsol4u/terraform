module "vpn-gtw" {
    for_each = local.vpn
    source        = "../modules/net-vpn-static/"
    project_id    = each.value.project_id
    region        = each.value.region
    network       = each.value.network
    name          = each.value.gw_name
    remote_ranges = each.value.remote_ranges
} 
resource "google_compute_vpn_tunnel" "tunnels" {
  for_each                = local.tunnels
  name                    = each.value.name
  project                 = each.value.project_id
  region                  = each.value.region
  peer_ip                 = module.vpn-gtw[each.value.peer_ip].address
  local_traffic_selector  = each.value.local_traffic_selector
  ike_version             = each.value.ike_version
  remote_traffic_selector = each.value.remote_traffic_selector
  shared_secret           = each.value.shared_secret 
  target_vpn_gateway      = module.vpn-gtw[each.value.source_gw].self_link
  depends_on              = [module.vpn-gtw]
} 
resource "google_compute_route" "routes" {
  for_each            = local.tunnels
  name                = each.value.name 
  project             = each.value.project_id
  network             = each.value.network
  dest_range          = each.value.dest_range
  priority            = each.value.priority
  next_hop_vpn_tunnel = google_compute_vpn_tunnel.tunnels[each.value.name].self_link
}