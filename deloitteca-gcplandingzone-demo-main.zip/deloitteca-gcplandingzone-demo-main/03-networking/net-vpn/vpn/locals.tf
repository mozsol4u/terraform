locals {
    vpn_config = flatten([for i in fileset(".", "yaml/*.yaml") : yamldecode(file(i))["vpn"]])
    vpn = {for obj in local.vpn_config : "${obj.gw_name}" => obj}
    tunnels_config = flatten([for gw in local.vpn : [
      for tunn in gw.tunnels :
      {
        name                      = tunn.name
        project_id                = gw.project_id
        region                    = gw.region
        network                   = gw.network
        source_gw                 = gw.gw_name
        peer_ip                   = tunn.peer_gw
        local_traffic_selector    = tunn.local_traffic_selector
        ike_version               = lookup(tunn,"ike_version", 2)
        remote_traffic_selector   = tunn.remote_traffic_selector
        shared_secret             = tunn.shared_secret
        dest_range                = tunn.dest_range
        priority                  = lookup(tunn,"priority", 1000)
      }
    ]
    ])
    tunnels = {for obj in local.tunnels_config : "${obj.name}" => obj}
}