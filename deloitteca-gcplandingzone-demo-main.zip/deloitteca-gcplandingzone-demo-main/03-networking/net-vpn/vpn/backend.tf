terraform {
  backend "gcs" {
    bucket = ""
    prefix = "terraform/networking/vpn/state"
  }
}