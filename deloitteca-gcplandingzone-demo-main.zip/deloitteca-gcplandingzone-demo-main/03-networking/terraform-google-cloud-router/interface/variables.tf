
variable "peers" {
  type        = any
  description = "BGP peers for this interface."
  default     = []
}