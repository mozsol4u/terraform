/*variable "project" {
  description = "the GCP project in CVS needs to be created"
}

variable "service_account" {
  description = "The account with credentials to provsion CVS"
}
*/


