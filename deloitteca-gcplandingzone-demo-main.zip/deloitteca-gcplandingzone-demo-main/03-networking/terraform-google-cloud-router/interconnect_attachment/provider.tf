terraform {
  required_version = ">= 0.13"
  required_providers {

    google = {
      source  = "hashicorp/google"
      version = ">= 4.27, < 5.0"
    }
  }
}
provider "google" {
  credentials = "keys.json"
}