locals {
  workloads = [for f in fileset(".", "*.yaml") : yamldecode(file("./${f}"))]
  gcp_folder = flatten([
    for workload in local.workloads :[
    for inter in workload.intercon : {
  
  name              = inter.name
  router            = inter.router
  project           = inter.project
  region            = inter.region
  #interconnect      = inter.interconnect
  admin_enabled     = inter.admin_enabled
  type              = inter.type
  description       = inter.description
  bandwidth         = inter.bandwidth
  mtu               = inter.mtu
  #candidate_subnets = inter.candidate_subnets
  vlan_tag8021q     = inter.vlan_tag8021q
      
    }
  ]
  ])

}

resource "google_compute_interconnect_attachment" "interconnect_attachment" {
  for_each = { for inter in local.gcp_folder : lower(inter.name) => inter }
  name              = each.value.name
  router            = each.value.router
  project           = each.value.project
  region            = each.value.region
  #interconnect      = each.value.interconnect
  admin_enabled     = each.value.admin_enabled
  type              = each.value.type
  description       = each.value.description
  bandwidth         = each.value.bandwidth
  mtu               = each.value.mtu
  #candidate_subnets = each.value.candidate_subnets
  vlan_tag8021q     = each.value.vlan_tag8021q
}

/*module "interface" {
  source                  = "../interface"
  name                    = var.interface.name
  project                 = var.project
  router                  = var.router
  region                  = var.region
  ip_range                = google_compute_interconnect_attachment.attachment.cloud_router_ip_address
  interconnect_attachment = google_compute_interconnect_attachment.attachment.self_link
  peers = [{
    name = var.peer.name

    # Peer IP Address must not contain the subnet mask, else will throw an invalid IP address error.
    peer_ip_address           = element(split("/", google_compute_interconnect_attachment.attachment.customer_router_ip_address), 0)
    peer_asn                  = var.peer.peer_asn
    advertised_route_priority = lookup(var.peer, "advertised_route_priority", null)
    bfd                       = lookup(var.peer, "bfd", null)
  }]
}
*/