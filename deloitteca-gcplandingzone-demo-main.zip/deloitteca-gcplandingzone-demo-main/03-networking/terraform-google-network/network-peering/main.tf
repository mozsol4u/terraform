

locals {
  fw = [for f in fileset(".", "*.yaml") : yamldecode(file("./${f}"))]
  gcp_folder = flatten([
    for firew1 in local.fw :[
    for sp1 in firew1.vpc_peering : {
    prefix = sp1.prefix
    local_network = sp1.local_network
    peer_network = sp1.peer_network
    export_peer_custom_routes = sp1.export_peer_custom_routes
    export_local_custom_routes = sp1.export_local_custom_routes
    export_peer_subnet_routes_with_public_ip = sp1.export_peer_subnet_routes_with_public_ip   
    export_local_subnet_routes_with_public_ip = sp1.export_local_subnet_routes_with_public_ip
    module_depends_on = sp1.module_depends_on
    local_network_peering_name = sp1.local_network_peering_name
    peer_network_peering_name = sp1.peer_network_peering_name
}
    ]
  ]
  )
}

resource "random_string" "network_peering_suffix" {
  upper   = false
  lower   = true
  special = false
  length  = 4
}

resource "google_compute_network_peering" "local_network_peering" {
   for_each = { for sp1 in local.gcp_folder : lower(sp1.prefix) => sp1 }
  #provider             = google-beta
  name                 = each.value.local_network_peering_name
  network              = each.value.local_network
  peer_network         = each.value.peer_network
  export_custom_routes = each.value.export_local_custom_routes
  import_custom_routes = each.value.export_peer_custom_routes

  export_subnet_routes_with_public_ip = each.value.export_local_subnet_routes_with_public_ip
  import_subnet_routes_with_public_ip = each.value.export_peer_subnet_routes_with_public_ip

  depends_on = [null_resource.module_depends_on]
}

resource "google_compute_network_peering" "peer_network_peering" {
  for_each = { for sp1 in local.gcp_folder : lower(sp1.prefix) => sp1 }
  #provider             = google-beta
  name                 = each.value.peer_network_peering_name
  network              = each.value.peer_network
  peer_network         = each.value.local_network
  export_custom_routes = each.value.export_peer_custom_routes
  import_custom_routes = each.value.export_local_custom_routes

  export_subnet_routes_with_public_ip = each.value.export_peer_subnet_routes_with_public_ip
  import_subnet_routes_with_public_ip = each.value.export_local_subnet_routes_with_public_ip

  depends_on = [null_resource.module_depends_on, google_compute_network_peering.local_network_peering]
}

resource "null_resource" "module_depends_on" {
  for_each = { for sp1 in local.gcp_folder : lower(sp1.prefix) => sp1 }
  triggers = {
    value = length(each.value.module_depends_on)
  }
}

resource "null_resource" "complete" {
  depends_on = [google_compute_network_peering.local_network_peering, google_compute_network_peering.peer_network_peering]
}