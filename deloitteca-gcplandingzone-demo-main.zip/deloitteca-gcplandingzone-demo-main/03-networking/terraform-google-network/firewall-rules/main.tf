
locals {
  fw = [for f in fileset(".", "*.yaml") : yamldecode(file("./${f}"))]
  gcp_folder = flatten([
    for firew1 in local.fw :[
    for fw1 in firew1.firewall_rules : {
  
  network_name = fw1.network_name
  custom_rules = fw1.custom_rules

    }
  ]
  ])

}  
locals {

  int_map = {for ig in local.gcp_folder : "${ig.network_name}" => ig}

    custom_rules_tag_map = {
    for val in local.custom_rules_tag: "${val.network_name}" => val
  }
   
  custom_rules_tag= [
    for k,val in local.int_map :
    val if val["custom_rules"] != null
  ]  

}




resource "google_compute_firewall" "custom" {
  
  #for_each = { for fw1 in local.gcp_folder : lower(fw1.network) => fw1 &&  fw1.custom_rules!= null }
  for_each                = local.custom_rules_tag_map
  name                    = each.value.custom_rules.name
  description             = each.value.custom_rules.description
  direction               = each.value.custom_rules.direction
  network                 = each.value.custom_rules.network
  project                 = each.value.custom_rules.project
  source_ranges           = each.value.custom_rules.direction == "INGRESS" ? each.value.custom_rules.ranges : null
  destination_ranges      = each.value.custom_rules.direction == "EGRESS" ? each.value.custom_rules.ranges : null
  source_tags             = each.value.custom_rules.use_service_accounts || each.value.custom_rules.direction == "EGRESS" ? null : each.value.custom_rules.sources
  source_service_accounts = each.value.custom_rules.use_service_accounts && each.value.custom_rules.direction == "INGRESS" ? each.value.custom_rules.sources : null
  target_tags             = each.value.custom_rules.use_service_accounts ? null : each.value.custom_rules.targets
  target_service_accounts = each.value.custom_rules.use_service_accounts ? each.value.custom_rules.targets : null
  disabled                = lookup(each.value.custom_rules.extra_attributes, "disabled", false)
  priority                = lookup(each.value.custom_rules.extra_attributes, "priority", 1000)

  dynamic "log_config" {
    for_each = lookup(each.value.custom_rules.extra_attributes, "flow_logs", false) ? [{
      metadata = lookup(each.value.custom_rules.extra_attributes, "flow_logs_metadata", "INCLUDE_ALL_METADATA")
    }] : []
    content {
      metadata = log_config.value.metadata
    }
  }

dynamic "allow" {
    for_each = [for rules in each.value.custom_rules.rules : rules if each.value.custom_rules.rules.action == "allow"]
    iterator = rules
    content {
      protocol = each.value.custom_rules.rules.protocol
      ports    = each.value.custom_rules.rules.ports
    }
  }

  dynamic "deny" {
    for_each = [for rule in each.value.custom_rules.rules : rule if each.value.custom_rules.rules.action == "deny"]
    iterator = rule
    content {
      protocol = each.value.custom_rules.rules.protocol
      ports    = each.value.custom_rules.rules.ports
    }
  }
}
