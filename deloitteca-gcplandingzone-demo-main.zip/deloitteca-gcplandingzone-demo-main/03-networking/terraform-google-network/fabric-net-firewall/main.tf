
###############################################################################
#                            rules based on IP ranges
###############################################################################
locals {
  fw = [for f in fileset(".", "*.yaml") : yamldecode(file("./${f}"))]
  gcp_folder = flatten([
    for firew1 in local.fw :[
    for fw1 in firew1.firewall : {
  
  network = fw1.network
  project_id = fw1.project_id
  internal_ranges_enabled = fw1.internal_ranges_enabled
  internal_ranges = fw1.internal_ranges
  internal_target_tags = fw1.internal_target_tags
  admin_ranges_enabled = fw1.admin_ranges_enabled
  admin_ranges = fw1.admin_ranges
  ssh_source_ranges = fw1.ssh_source_ranges
  ssh_target_tags = fw1.ssh_target_tags
  http_source_ranges = fw1.http_source_ranges
  http_target_tags = fw1.http_target_tags
  https_source_ranges = fw1.https_source_ranges
  https_target_tags = fw1.https_target_tags
  internal_allow = fw1.internal_allow
  target_tags = fw1.target_tags
  source_ranges = fw1.source_ranges
  custom_rules = fw1.custom_rules

    }
  ]
  ])

}  
locals {

  int_map = {for ig in local.gcp_folder : "${ig.network}" => ig}

    internal_all_map = {
    for val in local.allow_internal: "${val.network}" => val
  }
   admin_all_map = {
    for val in local.allow_admins: "${val.network}" => val
  }
     allow_tag_ssh_map = {
    for val in local.allow_tag_ssh: "${val.network}" => val
  }
  allow_tag_http_map = {
    for val in local.allow_tag_http: "${val.network}" => val
  }
  allow_tag_https_map = {
    for val in local.allow_tag_https: "${val.network}" => val
  }

    custom_rules_tag_map = {
    for val in local.custom_rules_tag: "${val.network}" => val
  }
   
   
   allow_internal = [
    for k,val in local.int_map :
    val if val["internal_ranges_enabled"] == true
  ]

  allow_admins = [
    for k,val in local.int_map :
    val if val["admin_ranges_enabled"] == true
  ]

  allow_tag_ssh= [
    for k,val in local.int_map :
    val if val["ssh_source_ranges"] != null
  ]

  allow_tag_http= [
    for k,val in local.int_map :
    val if val["http_source_ranges"] != null
  ]
  allow_tag_https= [
    for k,val in local.int_map :
    val if val["https_source_ranges"] != null
  ]

  custom_rules_tag= [
    for k,val in local.int_map :
    val if val["custom_rules"] != null
  ]  

}


resource "google_compute_firewall" "allow-internal" {
  for_each = local.internal_all_map
  name          = "${each.value.network}-ingress-internal"
  description   = "Allow ingress traffic from internal IP ranges"
  network       = each.value.network
  project       = each.value.project_id
  source_ranges = each.value.source_ranges
  target_tags   = each.value.internal_target_tags

  dynamic "allow" {
    for_each = [for rule in each.value.internal_allow :
      {
        protocol = lookup(rule, "protocol", null)
        ports    = lookup(rule, "ports", null)
      }
    ]
    content {
      protocol = allow.value.protocol
      ports    = allow.value.ports
    }
  }
}

resource "google_compute_firewall" "allow-admins" {
  #count         = var.admin_ranges_enabled == true ? 1 : 0
  for_each = local.admin_all_map
  name          = "${each.value.network}-ingress-admins"
  description   = "Access from the admin subnet to all subnets"
  network       = each.value.network
  project       = each.value.project_id
  source_ranges = each.value.source_ranges

  allow {
    protocol = "icmp"
  }

  allow {
    protocol = "tcp"
  }

  allow {
    protocol = "udp"
  }
}

###############################################################################
#                              rules based on tags
###############################################################################

resource "google_compute_firewall" "allow-tag-ssh" {
  for_each = local.allow_tag_ssh_map
  name          = "${each.value.network}-ingress-tag-ssh"
  description   = "Allow SSH to machines with the 'ssh' tag"
  network       = each.value.network
  project       = each.value.project_id
  source_ranges = each.value.ssh_source_ranges
  target_tags   = each.value.ssh_target_tags

  allow {
    protocol = "tcp"
    ports    = ["22"]
  }
}
 
resource "google_compute_firewall" "allow-tag-http" {
  for_each = local.allow_tag_http_map
  name          = "${each.value.network}-ingress-tag-http"
  description   = "Allow HTTP to machines with the 'http-server' tag"
  network       = each.value.network
  project       = each.value.project_id
  source_ranges = each.value.http_source_ranges
  target_tags   = each.value.http_target_tags

  allow {
    protocol = "tcp"
    ports    = ["80"]
  }
}

resource "google_compute_firewall" "allow-tag-https" {
   for_each = local.allow_tag_https_map
  name          = "${each.value.network}-ingress-tag-https"
  description   = "Allow HTTPS to machines with the 'https' tag"
  network       = each.value.network
  project       = each.value.project_id
  source_ranges = each.value.https_source_ranges
  target_tags   = each.value.https_target_tags

  allow {
    protocol = "tcp"
    ports    = ["443"]
  }
}

################################################################################
#                                dynamic rules                                 #
################################################################################

resource "google_compute_firewall" "custom" {
  
  #for_each = { for fw1 in local.gcp_folder : lower(fw1.network) => fw1 &&  fw1.custom_rules!= null }
  for_each                = local.custom_rules_tag_map
  name                    = each.value.custom_rules.name
  description             = each.value.custom_rules.description
  direction               = each.value.custom_rules.direction
  network                 = each.value.custom_rules.network
  project                 = each.value.custom_rules.project
  source_ranges           = each.value.custom_rules.direction == "INGRESS" ? each.value.custom_rules.ranges : null
  destination_ranges      = each.value.custom_rules.direction == "EGRESS" ? each.value.custom_rules.ranges : null
  source_tags             = each.value.custom_rules.use_service_accounts || each.value.custom_rules.direction == "EGRESS" ? null : each.value.custom_rules.sources
  source_service_accounts = each.value.custom_rules.use_service_accounts && each.value.custom_rules.direction == "INGRESS" ? each.value.custom_rules.sources : null
  target_tags             = each.value.custom_rules.use_service_accounts ? null : each.value.custom_rules.targets
  target_service_accounts = each.value.custom_rules.use_service_accounts ? each.value.custom_rules.targets : null
  disabled                = lookup(each.value.custom_rules.extra_attributes, "disabled", false)
  priority                = lookup(each.value.custom_rules.extra_attributes, "priority", 1000)

  dynamic "log_config" {
    for_each = lookup(each.value.custom_rules.extra_attributes, "flow_logs", false) ? [{
      metadata = lookup(each.value.custom_rules.extra_attributes, "flow_logs_metadata", "INCLUDE_ALL_METADATA")
    }] : []
    content {
      metadata = log_config.value.metadata
    }
  }

dynamic "allow" {
    for_each = [for rules in each.value.custom_rules.rules : rules if each.value.custom_rules.rules.action == "allow"]
    iterator = rules
    content {
      protocol = each.value.custom_rules.rules.protocol
      ports    = each.value.custom_rules.rules.ports
    }
  }

  dynamic "deny" {
    for_each = [for rule in each.value.custom_rules.rules : rule if each.value.custom_rules.rules.action == "deny"]
    iterator = rule
    content {
      protocol = each.value.custom_rules.rules.protocol
      ports    = each.value.custom_rules.rules.ports
    }
  }
}
