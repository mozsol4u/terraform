terraform {
  required_version = ">= 0.13.0"


}
  provider "google" {
  
     
      credentials = "keys.json"
  
}

