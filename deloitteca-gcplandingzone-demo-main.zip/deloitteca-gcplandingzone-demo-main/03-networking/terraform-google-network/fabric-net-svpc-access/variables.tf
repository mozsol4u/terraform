variable "host_service_agent_users" {
  type        = list(string)
  description = "List of IAM-style users that will be granted the host service agent role on the host project."
  default     = []
}