locals {
  fw = [for f in fileset(".", "*.yaml") : yamldecode(file("./${f}"))]
  gcp_folder = flatten([
    for firew1 in local.fw :[
    for sp1 in firew1.svpc : {
    host_project_id = sp1.host_project_id
    service_project_ids = sp1.service_project_ids
    host_subnets = sp1.host_subnets
    host_subnet_regions = sp1.host_subnet_regions
    host_subnet_users = sp1.host_subnet_users
    host_service_agent_role = sp1.host_service_agent_role
    host_service_agent_users = sp1.host_service_agent_users
    }
    ]
  ]
  )
}

locals {
   int_map = {for ig in local.gcp_folder : "${ig.host_project_id}" => ig}
  host_service_agent= [
    for k,val in local.int_map :
    val if val["host_service_agent_role"] == true
  ]
    host_service_agent_map = {
    for val in local.host_service_agent: "${val.host_project_id}" => val
  }
}

resource "google_compute_shared_vpc_service_project" "projects" {
  #provider        = google-beta
  #for_each        = { for i, k in toset(var.service_project_ids) : k => i }
  for_each = { for sp1 in local.gcp_folder : lower(sp1.host_project_id) => sp1 }
  host_project    = each.value.host_project_id
  service_project = each.key
}

resource "google_compute_subnetwork_iam_binding" "network_users" {
  #for_each = { for i, k in var.host_subnets : k => i }
for_each = { for sp1 in local.gcp_folder : lower(sp1.host_project_id) => sp1 }
  project    = each.value.host_project_id
  region     = each.value.host_subnet_regions
  subnetwork = each.key
  role       = "roles/compute.networkUser"
  members    = compact(split(",", lookup(each.value.host_subnet_users, each.key)))
}

resource "google_project_iam_binding" "service_agents" {
  #count   = var.host_service_agent_role ? 1 : 0
  for_each = local.host_service_agent_map
  project = each.value.host_project_id
  role    = "roles/container.hostServiceAgentUser"
  members = each.value.host_service_agent_users
}