terraform {
  required_providers {
    google = {
      source = "hashicorp/google"
      version = ">= 4.46.0"
    }
  }
}

provider "google" {
  credentials = file("../keys/superbootstrap.json") #file("../keys/grg-tf-projectfactory.json")
  }

provider "google-beta" {
  credentials = file("../keys/superbootstrap.json") #file("../keys/grg-tf-projectfactory.json")
  }