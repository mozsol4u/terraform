terraform {
  backend "gcs" {
    credentials = "../keys/superbootstrap.json" #"grg-tf-projectfactory.json"
    bucket = "sbybootstrap-bkt-new"
    prefix = "terraform/sobeys/sbyprbootstrap-prj-new/bootstrap"
  }
}