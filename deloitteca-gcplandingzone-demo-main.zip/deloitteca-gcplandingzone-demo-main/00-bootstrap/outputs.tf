# /*******************************************
#   Logs for debugging
#  *******************************************/
# output "config_local_values" {
#   value = local.config
# }

# output "folders_local_values" {
#   value = local.folders
# }

# output "projects_local_values" {
#   value = local.projects
# }