/******************************************
  Locals configuration
 *****************************************/
locals {
 
config = [for i in fileset(path.module, "configs/pv_bootstrap.yaml") : yamldecode(file(i))]

folders       =  flatten([
  for i, item in local.config:[
      for fk, folder in item.folders : {
        display_name = folder.display_name
        parent   = folder.parent
        prj_count= (folder.projects != null ? length(folder.projects) : 0)
      }
  ]
])

selected_billing_account_value = {
    for key, value in var.billing_account : key =>value }


projects      =  flatten([
  for i, item in local.config:[
      for fk, folder in item.folders : [
          for pk, project in folder.projects : {
          folder_name  = folder.display_name
          parent_id    = folder.parent
          project_name = project.project_name
          activate_apis = project.activate_apis
          create_default_project_sa = project.create_default_project_sa
          svpc_host_project_id = project.svpc_host_project_id
          shared_vpc_subnets = project.shared_vpc_subnets
          labels = project.labels
          billing_account = local.selected_billing_account_value[project.billing_account]
          project_sa_name = lookup(project,"project_sa_name","project-service-account")
          create_bucket   = project.create_bucket
          bucket          = lookup(project,"bucket",null)
          # bucket_name     = lookup(project,"bucket_name","")
          # bucket_location  = lookup(project,"bucket_location","US")
          # bucket_labels   = lookup(project,"bucket_labels",{})
          # bucket_versioning = lookup(project,"bucket_versioning",false)
          sa_role         = lookup(project,"sa_role","")
          } 
      ] if folder.projects != null
  ]
])

bucket_config = [
  for k, val in local.projects :
  val if val["create_bucket"] == true
]
bucket = flatten([
  for i, item in local.bucket_config:[
    for j, bkt in item.bucket:{
        project = item.project_name
        name = bkt.bucket_name
        location = bkt.bucket_location
        labels  = lookup(bkt,"bucket_labels",{})
        versioning = lookup(bkt,"bucket_versioning",true)
        force_destroy = lookup(bkt,"bucket_force_destroy",false)
        bucket_ula = lookup(bkt,"bucket_ula",true)
        bucket_pap = lookup(bkt,"bucket_pap",null)
        type       = lookup(bkt,"type","STANDARD")
        custom_placement_config = lookup(bkt,"custom_placement_config",{})
        member     = lookup(bkt,"member",null)
        role       = lookup(bkt,"role",null)

      }
  ]])
service_account = flatten([
  for i, item in local.projects:[
      for k, sa in item.project_sa_name :  {
        account_id = sa.name
        project = item.project_name
      }
  ]])

iam_roles = flatten([
  for i, item in local.projects:[
    for j, sa in item.project_sa_name: [
      for k, rle in sa.role :  {
        account_id = sa.name
        role = rle
        project = item.project_name
        org  = lookup(sa,"org",false)
        org_id = var.organization_id
        # sa   = sa
      }
  ]]])
}
# /*******************************************
#   Folder creation
#  *******************************************/
resource "google_folder" "folder_structure" {
  for_each         = {
      for f in local.folders : "${f.display_name}" => f
  }
  display_name = lookup(each.value, "display_name")
  parent = lookup(each.value, "parent")
}


 data "google_active_folder" "lookup_folder" {
  for_each         = {
      for f in local.folders : "${f.display_name}" => f
  }
   parent       = lookup(each.value, "parent")
   display_name = lookup(each.value, "display_name")
   depends_on   = [
    google_folder.folder_structure
  ]
 }

/*******************************************
  Project creation
 *******************************************/
module "project-factory" {
  source  = "../modules/project-factory"
  #version = "~> 14.1"

  depends_on       = [
    google_folder.folder_structure,
  ]

  for_each         = {
      for fp in local.projects : "${fp.project_name}" => fp
  }
      
  name                 = lookup(each.value, "project_name")
  random_project_id    = false
  org_id               = var.organization_id
  folder_id            = data.google_active_folder.lookup_folder[lookup(each.value, "folder_name")].id
  billing_account      = each.value.billing_account
  activate_apis        = lookup(each.value, "activate_apis")
  create_project_sa    = lookup(each.value, "create_default_project_sa")
  svpc_host_project_id = lookup(each.value, "svpc_host_project_id")
  shared_vpc_subnets   = lookup(each.value, "shared_vpc_subnets")
  labels               = lookup(each.value, "labels")
  # bucket_name          = each.value.bucket_name
  # bucket_project       = each.value.create_bucket == true ? lookup(each.value, "project_name") : ""
  # bucket_location      = each.value.bucket_location
  # bucket_labels        = each.value.bucket_labels
  # bucket_versioning    = each.value.bucket_versioning
}

resource "google_service_account" "service_account" {
  for_each         = {
      for sa in local.service_account : "${sa.project}-${sa.account_id}" => sa
  }
  depends_on       = [
    module.project-factory
  ]
  account_id   = each.value.account_id
  display_name = "${each.value.project} Project Service Account"
  project      = module.project-factory["${each.value.project}"].project_id
}

resource "google_project_iam_member" "default_service_account_membership" {
  for_each         = {
      for role in local.iam_roles : "${role.project}-${role.account_id}-${role.role}" => role
      if role.org == false
  }
  depends_on       = [
    resource.google_service_account.service_account
  ]
  project = module.project-factory["${each.value.project}"].project_id
  role    = each.value.role

  member = format("serviceAccount:%s",resource.google_service_account.service_account["${each.value.project}-${each.value.account_id}"].email)
}

resource "google_organization_iam_member" "organization_role" {
    for_each         = {
      for role in local.iam_roles : "${role.project}-${role.account_id}-${role.role}" => role
      if role.org == true
  }
    depends_on       = [
    resource.google_service_account.service_account
  ]
  org_id  = "${each.value.org_id}"
  role    = each.value.role
  member  = format("serviceAccount:%s",resource.google_service_account.service_account["${each.value.project}-${each.value.account_id}"].email)
}


resource "google_storage_bucket" "project_bucket" {
  provider = google-beta

  for_each         = {
      for f in local.bucket : "${f.name}-${f.project}" => f
  }

  name                        = each.value.name
  project                     = module.project-factory["${each.value.project}"].project_id
  location                    = each.value.location
  labels                      = each.value.labels
  force_destroy               = each.value.force_destroy
  uniform_bucket_level_access = each.value.bucket_ula
  public_access_prevention    = each.value.bucket_pap
  storage_class               = each.value.type
  versioning {
    enabled = each.value.versioning
  }
  dynamic "custom_placement_config" {
    for_each = lookup(each.value,"custom_placement_config",{}) != {} ? [each.value.custom_placement_config] : []
    content {
      data_locations = custom_placement_config.value
    }
  }
  depends_on   = [
    module.project-factory
  ]
}


resource "google_storage_bucket_iam_member" "public_bucket" {
  for_each = {
      for key, value in local.bucket :
      key => value if value["member"] != null
    }
  bucket                    = each.value.name
  role                      = "${each.value.role}"
  member                    = "${each.value.member}"
  depends_on   = [
    google_storage_bucket.project_bucket
  ]

}