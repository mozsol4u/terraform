variable "billing_account" {
  type  = map(string)
  default = {
    "primary_billing_account" = "01D090-45BA25-FFDC4F"
    #"sec_billing_account" = "<billing_account_id>"
  }
  
}

variable "organization_id" {
  type        = string
  description = "Organization ID"
  default  = "290265798990"
}
