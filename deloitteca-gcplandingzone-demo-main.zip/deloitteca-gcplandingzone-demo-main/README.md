# Release 1.0 | Feb 25th, 2025

Functionalities that have been added to this accelerator:
1. Central Logging: A log scope is created to enable the centralized viewing of logs from multiple projects within a central logging or monitoring project. This is achieved by specifying the central project ID in the```add_to_central_logscope``` flag. 
2. Budgeting: A Budget can be created for a project by defining the dollar amount in the ```budget_amount``` flag
3. Private Service Connect: It is created by specifying the psc name and psc ip address using the ```psc``` flag show below.
4. Cloud NAT

# deloitteca-gcplandingzone-demo

For further details please refer to this: [deloitteca-gcplandingzone-accelerator](https://github.com/Deloitte-Default/deloitteca-gcplandingzone-accelerator/tree/psc-dev)
