# variable "scoping_project_id" {
#   default = "networkingproj101-0e59"
# }

# variable "scoping_project_ids" {
#   type        = list(string)
#   description = "List of project IDs to be monitored"
#   default     = ["networkingproj101-0e59", "testpro101-9c12", "testpro102-aad5"]
# }

variable "monitoring_project_id" {
  type        = string
  description = "This variables defines the monitoring project(s)"
  default = ""#"monitoringproj101-afd2"

}


/*variable "email_audience" {
  type        = string
  description = "This variables defines the monitoring email_audience"

}

variable "email_audience1" {
  type        = string
  description = "This variables defines the monitoring email_audience1"

}
*/
/*
variable "snow_endpoint" {
  type        = string
  description = "This variables defines the monitoring webhook endpoint"
}

variable "snow_auth_username" {
  type        = string
  description = "This variables defines the monitoring basic auth "
}

variable "snow_auth_password" {
  type        = string
  description = "This variables defines the monitoring basic auth "
}

variable "policies" {
  type        = any
  description = "The alert policies."
  default     = []
}

variable "nc" {
  type        = any
  description = "The notification channel."
  default     = []
}


variable "display_name" {}

variable "filter" {}

variable "dashboardname" {}

variable "team" {}

#variable "display_name_nc" {}
*/