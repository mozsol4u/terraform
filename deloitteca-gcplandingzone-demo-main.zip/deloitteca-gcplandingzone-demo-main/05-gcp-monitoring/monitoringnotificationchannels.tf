# Notification Setup
locals {
  nch = [for f in fileset(".", "configs/*.yaml") : yamldecode(file("./${f}"))]
  gcp_folder2 = flatten([
    for p in local.nch :[
    for n in p.nc : {
      display_name = n.display_name
      email_audience = n.email_audience
    }]])
  }


resource "google_monitoring_notification_channel" "email" {
  for_each     = { for n in local.gcp_folder2 : lower(n.display_name) => n }
  display_name = each.value.display_name
  project = "${var.monitoring_project_id}"
  type         = "email"
  enabled = true
  labels = {
    email_address = each.value.email_audience
  }
}


#placeholder for SNOW
/*locals {
  snow = [for f in fileset(".", "*.yaml") : yamldecode(file("./${f}"))]
  gcp_folder2 = flatten([
    for p in local.snow :[
    for s in p.snownc : {
      display_name = s.display_name
      email_audience = s.email_audience
    }]])
  }
*/


/*resource "google_monitoring_notification_channel" "snow-notification" {
  for_each     = { for s in local.gcp_folder2 : lower(s.display_name) => s }
  display_name = "ServiceNow - webhook"
  project = "${var.monitoring_project_id}"
  type         = "webhook_basicauth"
  labels = {
    url = each.value.snow_endpoint
    username = each.value.snow_auth_username
  }
  sensitive_labels {
    password = each.value.snow_auth_password
  }
  enabled = "true"
}
*/
