locals {
  grps = [for f in fileset(".", "configs/*.yaml") : yamldecode(file("./${f}"))]
  gcp_folder3 = flatten([
    for p in local.grps :[
    for g in p.grp : {
      display_name = g.display_name
      filter = g.filter
    }]])
  }

resource "google_monitoring_group" "test1" {
  for_each     = { for g in local.gcp_folder3 : lower(g.display_name) => g }
  display_name = each.value.display_name
  filter =  each.value.filter
  project = "${var.monitoring_project_id}"
}

