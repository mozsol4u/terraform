terraform {
  backend "gcs" {
    credentials = "../keys/monitoringproj101-afd2-5e7f6c154e32.json"
    bucket = "testmonitoringbucpro110"
    prefix = "terraform/demosobeys/monitoring/state"
  }
}