# Configuring the terraform version

terraform {
  required_providers {
    google = {
      source = "hashicorp/google"
      version = "6.14.1"
    }
  }
}

provider "google" {
  credentials = "${file("../keys/monitoringproj101-afd2-5e7f6c154e32.json")}"
}