Requirements
These sections describe requirements for using this module.

Software
The following dependencies must be available:

Terraform v0.12
Terraform Provider for GCP plugin v2.0
Google Cloud SDK
curl
Service Account
A service account with the following roles must be used to provision the resources of this module:


APIs
A project with the following APIs enabled must be used to host the resources of this module:
Google Cloud Monitoring API: monitoring.googleapis.com



This module creates following:
1.Monitoring dashboard

2.Notification channels

3.Alert policies

4.Monitoring Groups


Folder- monitoring- contains json file for dahsboard with layout

monitoringroups.tf - This file is used for creating monitoring groups.

monitoringalerts.tf - This file holds the code for policies

monitoringdashboard.tf- This file holds details for dashboard- project, name and team

monitoringnotificationchannels.tf- This file creates the required email and SNOW notification channel

scopingproject.tf - This file hold the name of scoping and monitored project

monitoring.yaml - This file needs to be input to provide all inputs for groups, dashboard, policy and notification channel.

Steps:

1. provide input json- for creating dashboard with required matrics

2. Create notification channels and output the id of notification channel created

3. add scoping project- which holds resources to be tracked

4. Create monitoring groups

5. Create the monitoring dashboard

6. Create alerts policies and add notifications channels to those policies
