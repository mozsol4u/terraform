############ Monitoring Dashboard ##############
  locals {
  dashb = [for f in fileset(".", "configs/*.yaml") : yamldecode(file("./${f}"))]
  gcp_folder1 = flatten([
    for p in local.dashb :[
    for d in p.dash : {
      team = d.team
      dashboardname= d.dashboardname
      monitored_project_id= d.monitored_project_id
    }]])
  }



resource "google_monitoring_dashboard" "test1-dashboard-INTERCONNECT_MONITORING" {
  for_each     = { for d in local.gcp_folder1 : lower(d.team) => d }
  project = "${var.monitoring_project_id}"
  dashboard_json = templatefile(
    "./monitoring/Monitoring Dashboard.json",
    {
      TEAM  = each.value.team
      DASHBOARDNAME = each.value.dashboardname
      PROJECT1 = each.value.monitored_project_id#var.scoping_project_id
    }
  )
}


