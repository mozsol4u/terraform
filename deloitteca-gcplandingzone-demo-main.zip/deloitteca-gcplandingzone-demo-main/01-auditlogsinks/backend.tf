terraform {
   backend "gcs" {
    bucket = "sbylogsink-bkt-new" #for terraform statefile
    prefix = "terraform/sobeys/sbyprlogsinks-prj-new/logsinks"
  }
}