terraform {
  required_providers {
    google = {
      source = "hashicorp/google"
      version = ">= 4.46.0"
    }
  }
}

provider "google" {
  credentials = file("../keys/new/sbyprlogsinks-prj-new.json") #file("../keys/sbyprbootstrap-prj-tst.json")
  }

provider "google-beta" {
  credentials = file("../keys/new/sbyprlogsinks-prj-new.json") #file("../keys/sbyprbootstrap-prj-tst.json")
  }

#credentials = file("../keys/sbyprlogsinks-prj-tst.json")