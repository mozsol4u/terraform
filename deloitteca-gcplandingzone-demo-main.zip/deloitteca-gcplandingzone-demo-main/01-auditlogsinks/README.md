# Organization Audit Logs #

This module allows management of audit logging for a given service for a Google Cloud Platform Organization. It supports:

* creating a sink bucket in a project and sinking the audit logs to it.
* enabling audit logging for the specified services and grant one of these permissions: DATA_READ, DATA_WRITE, or ADMIN_READ
* exempting specified identities that do not cause logging for this type of permission. Each entry can have one of the following values:

    *   user:{emailid}: An email address that represents a specific Google account. For example, alice@gmail.com or joe@example.com.
    *   serviceAccount:{emailid}: An email address that represents a service account. For example, my-other-app@appspot.gserviceaccount.com.
    *   group:{emailid}: An email address that represents a Google group. For example, admins@example.com.
    *   domain:{domain}: A G Suite domain (primary, instead of alias) name that represents all the users of that domain. For example, google.com or example.com.

### Operational considerations ###

* The configuration consists in one YAML files in "configs" folder of this repository. A valid schema of the yaml is as below:

```yaml
organization_id: "<ORGANIZATION_ID>"
log_sink_project_id: "<PROJECT_ID>"
log_sink_bucket_name: "<BUCKET_NAME>"
log_sink_bucket_location: "<BUCKET_REGION>"

audit_services:
  - service_api: "dns.googleapis.com"
    log_types_config:
      - log_type: "ADMIN_READ"
        exempted_members:
          - user:example@deloitte.ca
          - user:example@gmail.com
          - group:example@deloittecloudaccelerator.ca
      - log_type: "DATA_WRITE"
        exempted_members:
          - user:example@deloitte.ca
          - user:example@gmail.com
      - log_type: "DATA_READ"
        exempted_members:
  - service_api: "compute.googleapis.com"
    log_types_config:
      - log_type: "ADMIN_READ"
        exempted_members:
          - user:example@deloitte.ca
          - user:example@gmail.com
```
