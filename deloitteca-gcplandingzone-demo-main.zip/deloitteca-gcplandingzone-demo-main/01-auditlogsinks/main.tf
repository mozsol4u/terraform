/******************************************
  Locals configuration
 *****************************************/
locals {

config = yamldecode(file("configs/audit-logs.yaml"))

audit-services                       =  flatten([
  for i, item in local.config.audit_services:{
            service                  = item.service_api
            log_types_config         = item.log_types_config
            }
])
 }

################################################################################
#                           Log Sink Bucket Creation                           #
################################################################################

resource "google_storage_bucket" "org-logsink" {

  name           = local.config.log_sink_bucket_name
  project        = local.config.log_sink_project_id
  location       = local.config.log_sink_bucket_location
}

################################################################################
#                             Log Sink Management                              #
################################################################################

resource "google_logging_organization_sink" "org-logsink" {
  
  description = "org-logs to central storage bucket"
  org_id        = local.config.organization_id
  name        = "logsink-to-${local.config.log_sink_project_id}"
  destination = "storage.googleapis.com/${local.config.log_sink_bucket_name}"
  depends_on   = [
    google_storage_bucket.org-logsink
  ]
}


resource "google_project_iam_member" "log-writer" {
  project = local.config.log_sink_project_id
  role    = "roles/storage.objectCreator"
  member  = google_logging_organization_sink.org-logsink.writer_identity
  depends_on   = [
    google_storage_bucket.org-logsink
  ]
}


resource "google_organization_iam_audit_config" "api-audit-logging" {
  for_each          = {
    for s in local.audit-services  : "${s.service}" => s
  }
  org_id = local.config.organization_id
  service = lookup(each.value, "service")

  dynamic "audit_log_config" {
    for_each = lookup(each.value, "log_types_config")
    content {
      log_type = audit_log_config.value["log_type"]
      exempted_members = try(audit_log_config.value["exempted_members"], null)
    }
  }

}