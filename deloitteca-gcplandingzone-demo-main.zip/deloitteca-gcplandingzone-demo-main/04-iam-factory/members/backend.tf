terraform {
  backend "gcs" {
    credentials = "../../keys/new/sbyiamfactory-new.json"
    bucket = "sbyiamfactory-bkt-new" #prjfct-bucket"
    prefix = "terraform/demosobeys/iam/state"
  }
}

