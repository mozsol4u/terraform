locals {

  input = flatten([for i in fileset(".", "config/*.yaml") : yamldecode(file(i))])
  mbrs = flatten([ for val  in local.input: 
              val["roles"] if contains(keys(val), "roles")])
  iam_roles = flatten([
  for i, item in local.mbrs:[
    for m, mem in item.member: [
        for j, role in mem.role: {
            level = item.level
            role =  role
            member = "${mem.name}"
            project_id = "${lookup(item,"project_id",null)}"  
            org_id = "${lookup(item,"org_id",null)}"
            folder_id = "${lookup(item,"folder_id",null)}"
        }
        ]
    ]])

#   #Checking for Project level 
  mbrs_prj = [
    for k, val in local.iam_roles :
    val if val["level"] == "project"
  ]
  prj = {
    for val in local.mbrs_prj: "${val.project_id}-${val.member}-${val.role}" => val
  }
#   #Checking for Folder level 
  mbrs_fldr = [
    for k, val in local.iam_roles :
    val if val["level"] == "folder"
  ]
  fldr = {
    for val in local.mbrs_fldr: "${val.folder_id}-${val.member}-${val.role}" => val
  }
# #Checking for Organization level 
  mbrs_org = [
    for k, val in local.iam_roles :
    val if val["level"] == "org"
  ]
  org = {
    for val in local.mbrs_org: "${val.org_id}-${val.member}-${val.role}" => val
  }

}
