resource "google_project_iam_member" "project_role" {
  for_each         = local.prj
  project = "${each.value.project_id}"
  role    = each.value.role
  member = each.value.member
}

resource "google_folder_iam_member" "folder_role" {
  for_each = local.fldr
  folder  = "${each.value.folder_id}"
  role    = each.value.role
  member = each.value.member
}

resource "google_organization_iam_member" "organization_role" {
  for_each         = local.org
  org_id  = each.value.org_id
  role    = each.value.role
  member = each.value.member
}

