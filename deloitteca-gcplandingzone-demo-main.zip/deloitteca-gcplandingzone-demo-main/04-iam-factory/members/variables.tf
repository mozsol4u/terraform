# variable "google_credentials" {
#   description = "Google Cloud service account key in JSON format"
#   type        = string
#   default     = "" # Leave empty to force using the environment variable
# }
