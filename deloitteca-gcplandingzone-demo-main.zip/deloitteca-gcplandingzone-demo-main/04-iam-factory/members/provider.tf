terraform {
  required_providers {
    google = {
      source = "hashicorp/google"
      version = "4.57.0"
    }
  }
}

provider "google" {
  #credentials = var.google_credentials
  credentials = file("../../keys/new/sbyiamfactory-new.json")
  }

provider "google-beta" {
  #credentials = var.google_credentials
  credentials = file("../../keys/new/sbyiamfactory-new.json")
  }