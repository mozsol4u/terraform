# README #

This README would normally document whatever steps are necessary to get your application up and running.

### What is this repository for? ###

Assigning Permissions to Groups, Users or ServiceAccounts


### Folder Definitions
config: To keep input files for the code

### Yaml File Breakdown ###

To assign permissions ,yaml file Should have a block name ***roles*** which can consist of list of elements each representing a new configuration for roles/permissions 

|     Field                       | Description                                                                                                                                                                        |
| ------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
|     level                       | Permission level, can be either "project", "org" or "folder"                                                                                                                       |
|     project_id/folder_id/org_id | On the basis of level, specify project_id or folder_id or org_id                                                                                                                   |
|     member                      | List of Members to whom permission is to be applied                                                                                                                                |
|       - name                    | Full Id of member with identifier , ex to assign permission to SA value should be "serviceAccount:SA_full_id", for User "user:full_user_id", for Groups "group:group_id/group_key" |
|         role                    | List of roles/permissions                                                                                                                                                          |