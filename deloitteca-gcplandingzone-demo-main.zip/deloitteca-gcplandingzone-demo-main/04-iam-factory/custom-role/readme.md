# README #

This README would normally document whatever steps are necessary to get your application up and running.

### What is this repository for? ###

Creating Custom Roles


### Folder Definitions
config: To keep input files for the code

### Yaml File Breakdown ###

To custom roles ,yaml file Should have a block name ***roles*** which can consist of list of elements each representing a new configuration for roles

|      Field                       | Description                                                      |
| -------------------------------- | ---------------------------------------------------------------- |
|      level                       | Permission level, can be either "project", "org" or "folder"     |
|      project_id/folder_id/org_id | On the basis of level, specify project_id or folder_id or org_id |
|      role_id                     | Role id , ex pv_prj_role                                         |
|      title                       | Display Name / Title of the Role                                 |
|      permissions                 | List of Granular Permissions role is made of                     |