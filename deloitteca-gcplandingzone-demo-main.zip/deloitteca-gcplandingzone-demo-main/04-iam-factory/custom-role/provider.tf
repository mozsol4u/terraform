terraform {
  required_providers {
    google = {
      source = "hashicorp/google"
      version = "4.57.0"
    }
  }
}

# provider "google" {
#     #Configuration options
#   credentials = file("creds.json")
#   }

# provider "google-beta" {
#     # Configuration options
#   credentials = file("creds.json")
#   }