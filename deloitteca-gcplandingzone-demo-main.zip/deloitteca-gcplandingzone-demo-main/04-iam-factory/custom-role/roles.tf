locals {
  input = flatten([for i in fileset(".", "config/*.yaml") : yamldecode(file(i))])
  roles = flatten([ for val  in local.input: 
              val["roles"] if contains(keys(val), "roles")])
custom_roles = flatten([
  for i, item in local.roles: {
            level = item.level
            role_id =  item.role_id
            title = "${item.title}"
            project_id = "${lookup(item,"project_id",null)}"  
            org_id = "${lookup(item,"org_id",null)}"
            permissions = item.permissions
            description = "${lookup(item,"description",null)}"
          }
    ])

 role_map = {for j in local.custom_roles : "${j.role_id}" => j}

  #Checking for Porject level Custom Role Parameters
 role_prj = [
    for k, val in local.role_map :
    val if val["level"] == "project"
  ]
  prj_role = {
    for val in local.role_prj: val.role_id => val
  }
  #Checking for Organization Level Custom Role Parameters
 role_org = [
    for k, val in local.role_map :
    val if val["level"] == "organization"
  ]
  org_role = {
    for val in local.role_org: val.role_id => val
  }
  }


resource "google_project_iam_custom_role" "my-custom-project-test-role" {
  for_each    = local.prj_role
  project     = each.value.project_id
  role_id     = each.value.role_id
  title       = each.value.title
  permissions = each.value.permissions
  description = each.value.description
}

resource "google_organization_iam_custom_role" "my-custom-org-test-role" {
  for_each    = local.org_role
  org_id      = each.value.org_id
  role_id     = each.value.role_id
  title       = each.value.title
  permissions = each.value.permissions
  description = each.value.description
}
