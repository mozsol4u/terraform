locals {
  bnd = [for f in fileset(".", "config/*.yaml") : yamldecode(file("./${f}"))]
  folder3 = flatten([
    for i in local.bnd :[
    for j in i.bindings : {
      level = j.level
      role = j.role
      members = j.members
      project = "${lookup(j,"project",null)}"  
      org_id = "${lookup(j,"org_id",null)}"
      folder = "${lookup(j,"folder",null)}"
    }]])

  bnd_map = {for j in local.folder3 : lower(j.role) => j}
  #Checking for Porject level Binding Details
  prj_bnd = [
    for k, val in local.bnd_map :
    val if val["level"] == "project"
  ]
  pbnd = {
    for val in local.prj_bnd: "$(val.project)-$(val.role)" => val
  }
  #Checking for Folder level Binding Details
  fld_bnd = [
    for k, val in local.bnd_map :
    val if val["level"] == "folder"
  ]
  fbnd = {
    for val in local.fld_bnd: "$(val.folder)-$(val.role)" => val
  }
#Checking for Organization level Binding Details
  org_bnd = [
    for k, val in local.bnd_map :
    val if val["level"] == "organization"
  ]
  orgbnd = {
    for val in local.org_bnd: "$(val.org_id)-$(val.role)" => val
  }
  }

resource "google_project_iam_binding" "projectbinding" {
  for_each = local.pbnd
  role = each.value.role
  members =  each.value.members   
  project = each.value.project
}

resource "google_folder_iam_binding" "folderbinding" {
  for_each = local.fbnd
  role = each.value.role
  members =  each.value.members   
  folder = each.value.folder
}

resource "google_organization_iam_binding" "organizationbinding" {
  for_each = local.orgbnd
  role = each.value.role
  members =  each.value.members   
  org_id = each.value.org_id
}


