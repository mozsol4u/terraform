# README #

This README would normally document whatever steps are necessary to get your application up and running.

### What is this repository for? ###

Creating Custom Roles


### Folder Definitions
config: To keep input files for the code

### Yaml File Breakdown ###

To custom roles ,yaml file Should have a block name ***bindings*** which can consist of list of elements each representing a new configuration for bindings


|Name|Description|Type|Required|
|:----|:----|:----|:----|
|level|Level at which the member is present |string|yes|
|project|Project ID|string|yes|
|folder|Folder ID|string|yes|
|org_id|Organization ID|string|yes|
|role|Role which should be assigned to the member|string|yes|
|members|Member details to which the role should be assigned |list(string)|yes|
