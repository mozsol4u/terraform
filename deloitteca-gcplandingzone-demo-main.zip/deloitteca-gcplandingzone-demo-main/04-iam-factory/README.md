IAM Factory
Identity and Access Management (IAM) lets administrators authorize who can take action on specific resources, giving you full control and visibility to manage Google Cloud resources centrally. This code enables deployment of custom roles at project and organization levels. This code allows group creation , group membership, new member creation and/or assigning roles to an existing member. A member could be a User, Group or Service Account. This could be used at Organization, Folder or even Project level.

A role contains a set of permissions that allows you to perform specific actions on Google Cloud resources. Custom roles are user-defined, and allow you to bundle one or more supported permissions to meet your specific needs. A binding binds one or more members , or principals, to a single role. 

Folder Definitions
The IAM factory folders are as below:
	1. Custom-role - for creation of custom roles at project and organization level
	2. Members - creation of new users and granting permissions to new users as well as existing members. Non-Authoritative
    3. Bindings - granting permissions to existing members. Authoritative
	4. Cloud-Identity-Group - for creation of groups
	5. Cloud-Organization-Policy - Organization Policies




Note:- Based on the level you mention its corresponding value should be mentioned. Eg: if the level is "project" only Project ID value should be provided and rest of the parameters ie, org_id and folder id is not required.

Format for Members
Group names:
[GROUP_NAME]@[ORGANIZATION_ID].iam.gserviceaccount.com
[GROUP_NAME]@[FOLDER_ID].iam.gserviceaccount.com
[GROUP_NAME]@[PROJECT_ID].iam.gserviceaccount.com

Service Account:
[SERVICE_ACCOUNT_NAME]@[PROJECT_ID].iam.gserviceaccount.com

How to Run the code:

Run the following command from within each directory
- terraform init to get the plugins 
- terraform plan to see the infrastructure plan 
- terraform apply to apply the infrastructure build 
- terraform destroy to destroy the built infrastructure

Use-cases:
- Creation of a new user
- Creation of custom role
- Attaching Role to users, service account or groups
- Creation of cloud entity group and group membership

Limitations:
google_project_iam_binding resources can be used in conjunction with google_project_iam_member resources only if they do not grant privilege to the same role.

This resource google_organization_iam_member must not be used in conjunction with google_organization_iam_binding for the same role or they will fight over what your policy should be.

Roles controlled by google_folder_iam_binding should not be assigned to using google_folder_iam_member

Guidelines:
Identity and Access Management (IAM) API should be enabled in the GCP account.
The service account used for the creation should have access at Organization, Folder and Project levels.