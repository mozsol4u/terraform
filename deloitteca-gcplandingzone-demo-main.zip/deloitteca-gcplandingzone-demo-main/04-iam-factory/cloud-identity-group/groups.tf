locals {
  input = flatten([for i in fileset(".", "config/*.yaml") : yamldecode(file(i))])
  groups = flatten([ for val  in local.input: 
              val["groups"] if contains(keys(val), "groups")])
  grp = flatten([
    for i, item in local.groups : {
        display_name = item.display_name
        group_key = item.group_key
        labels = item.labels
        initial_group_config = item.initial_group_config
        description  = lookup(item,"description",null)
        preferred_member_key = item.preferred_member_key
    }])

  grp_map = {for j in local.grp : "${j.display_name}" => j}

  add_members = flatten([
  for i, item in local.grp_map:[
        for u, usr in item.preferred_member_key: [
            for k, val in usr.id:
                {
                group = item.display_name
                id    = val
                role =  usr.roles
               }
           ]
        ]])
members = {
    for val in local.add_members: "${val.group}-${val.id}-${val.role}" => val
  }
}

resource "google_cloud_identity_group" "groups" {
  for_each     = local.grp_map
  display_name = each.value.display_name
  parent       = var.parent_id
  description  = each.value.description
  labels       = each.value.labels
  initial_group_config = each.value.initial_group_config


  group_key  {
        id = each.value.group_key
    }
  
}

resource "null_resource" "previous" {
  depends_on = [ google_cloud_identity_group.groups ]
}

resource "time_sleep" "wait_60_seconds" {
  depends_on = [null_resource.previous]

  create_duration = "60s"
}


resource "google_cloud_identity_group_membership" "adding_members" {
  for_each     = local.members
  depends_on = [ 
    google_cloud_identity_group.groups, time_sleep.wait_60_seconds ]
  group        = google_cloud_identity_group.groups[each.value.group].id
  preferred_member_key {
    id = "${each.value.id}"
  }
  roles {
    name = "${each.value.role}"
  }
  roles {
    name = "MEMBER"
  }

}