# README #

This README would normally document whatever steps are necessary to get your application up and running.

### What is this repository for? ###

Deploying Multiple Google Groups


### Folder Definitions
config: To keep input files for the code

### Yaml File Breakdown ###

To create ***Google Groups***, yaml file Should have a block name ***groups*** which can consist of list of elements each representing a new configuration for Google Groups 




|     Field                                                                                | Description                                                                                                                                                                                                                                                         |
| ---------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
|     display_name                                                                         | Display Name of the Group                                                                                                                                                                                                                                           |
|     group_key                                                                            | Group Email ID, ex display_name@domain.com                                                                                                                                                                                                                          |
|     #Possible values are INITIAL_GROUP_CONFIG_UNSPECIFIED, WITH_INITIAL_OWNER, and EMPTY |                                                                                                                                                                                                                                                                     |
|     initial_group_config                                                                 | The initial configuration options for creating a Group. Possible values are INITIAL_GROUP_CONFIG_UNSPECIFIED, WITH_INITIAL_OWNER, and EMPTY.                                                                                                                        |
|     labels                                                                               | One or more label entries that apply to the Group. Currently supported labels contain a key with an empty value. Google Groups are the default type of group and have a label with a key of cloudidentity.googleapis.com/groups.discussion_forum and an empty value |
|     description                                                                          | Group Description                                                                                                                                                                                                                                                   |
|     preferred_member_key                                                                 | EntityKey of the member.                                                                                                                                                                                                                                            |
|       - roles                                                                            | The name of the MembershipRole. Must be one of OWNER, MANAGER, MEMBER                                                                                                                                                                                               |
|         id                                                                               | ID of Google Managed Identities, ex user@domain                                                                                                                                                                                                                     |