variable "parent_id" {
  type        = string
  description = "Google Customer ID"
  default  = "<customer ID"  //to be fetched from cloud identity 
}