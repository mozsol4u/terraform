#!/usr/bin/env bash
set -euo pipefail

# lsam-opcon-register.sh: register/deregister this LSAM pod as an OpCon Machine via REST API
# Requires env:
#   OPCON_BASE_URL  - e.g., https://opcon.example.com
#   OPCON_TOKEN     - recommended (Authorization: Token <token>)
#   MACHINE_GROUP   - OpCon Machine Group to join
# Optional:
#   VERIFY_TLS=false to skip TLS verification (curl -k)
#
# USAGE (inside pod):
#   /scripts/lsam-opcon-register.sh register
#   /scripts/lsam-opcon-register.sh deregister

VERIFY_OPT=""
if [[ "${VERIFY_TLS:-true}" == "false" ]]; then
  VERIFY_OPT="-k"
fi

if [[ $# -lt 1 ]]; then
  echo "Usage: $0 register|deregister" >&2
  exit 2
fi

ACTION=$1
POD_NAME=${HOSTNAME:-$(hostname)}
MACHINE_NAME=${MACHINE_NAME:-$POD_NAME}
AUTH_HEADER=( -H "Authorization: Token ${OPCON_TOKEN}" )
BASE="${OPCON_BASE_URL%/}"

# Helper to call OpCon API (JSON)
api_get(){ curl -sS ${VERIFY_OPT} "${BASE}$1" "${AUTH_HEADER[@]}"; }
api_post(){ curl -sS ${VERIFY_OPT} -X POST "${BASE}$1" -H 'Content-Type: application/json' "${AUTH_HEADER[@]}" -d "$2"; }
api_put(){ curl -sS ${VERIFY_OPT} -X PUT  "${BASE}$1" -H 'Content-Type: application/json' "${AUTH_HEADER[@]}" -d "$2"; }
api_del(){ curl -sS ${VERIFY_OPT} -X DELETE "${BASE}$1" "${AUTH_HEADER[@]}"; }

# Obtain Machine by name → id
get_machine_id(){
  api_get "/api/machines?name=${MACHINE_NAME}" | jq -r 'if type=="object" and has("items") then .items[0].id else (.[0].id // empty) end'
}

# Create machine payload (Linux LSAM)
create_machine(){
  cat <<JSON
{
  "name": "${MACHINE_NAME}",
  "type": "UNIX",                
  "socket": 3100,
  "maxJobs": 5,
  "enabled": true,
  "documentation": "Auto-registered from ARO pod",
  "groups": ["${MACHINE_GROUP}"]
}
JSON
}

# Limit (stop job starts) gracefully
limit_machine(){
  local id=$1
  api_put "/api/machines/${id}" '{"enabled":false}' >/dev/null || true
}

# Register flow
register(){
  echo "[lsam-opcon] registering ${MACHINE_NAME} in group ${MACHINE_GROUP}"
  # Create or update
  local id
  id=$(get_machine_id || true)
  if [[ -z "$id" || "$id" == "null" ]]; then
    api_post "/api/machines" "$(create_machine)" >/dev/null
    echo "[lsam-opcon] machine created"
  else
    api_put "/api/machines/${id}" "$(create_machine)" >/dev/null
    echo "[lsam-opcon] machine updated (${id})"
  fi
}

# Deregister flow (preStop)
# Steps: limit → wait short → delete
_deregister(){
  local id
  id=$(get_machine_id || true)
  if [[ -z "$id" || "$id" == "null" ]]; then
    echo "[lsam-opcon] machine not found; nothing to do"
    return 0
  fi
  echo "[lsam-opcon] limiting machine before removal..."
  limit_machine "$id"
  sleep 5
  echo "[lsam-opcon] deleting machine ${id}"
  api_del "/api/machines/${id}" >/dev/null || true
}

case "$ACTION" in
  register) register ;;
  deregister) _deregister ;;
  *) echo "Unknown action: $ACTION" ; exit 2 ;;
 esac
