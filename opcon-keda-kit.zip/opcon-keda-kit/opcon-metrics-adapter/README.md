# opcon-metrics-adapter
A tiny FastAPI service that exposes `/v1/backlog` so **KEDA metrics-api scaler** can autoscale LSAM pods on backlog.

## Environment variables
- `OPCON_BASE_URL` (required) – e.g. `https://opcon.example.com`
- `OPCON_TOKEN` (preferred) – Application token for OpCon REST API (`Authorization: Token <token>`)
- `OPCON_USERNAME`/`OPCON_PASSWORD` (optional) – if you cannot use `OPCON_TOKEN`, the adapter will POST `/api/tokens` to obtain a temporary token
- `DEFAULT_MACHINE_GROUP` – default OpCon Machine Group (e.g., `lsam-aro`)
- `BACKLOG_STATUSES` – comma-separated statuses treated as backlog (default: `Waiting,Queued`)
- `VERIFY_TLS` – `true|false` (default: `true`)

## Run locally
```bash
export OPCON_BASE_URL=https://opcon.example.com
export OPCON_TOKEN=Token_XXXX
uvicorn app.main:app --host 0.0.0.0 --port 8080
```

## Build
```bash
docker build -t yourrepo/opcon-metrics-adapter:1.0.0 .
```
