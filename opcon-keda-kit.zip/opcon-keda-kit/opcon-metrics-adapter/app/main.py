# opcon-metrics-adapter: a tiny API that exposes /v1/backlog for KEDA metrics-api scaler
# Language: Python 3.x
# Framework: FastAPI + Uvicorn
# Purpose: Query OpCon REST API to compute backlog for LSAM worker pods (Linux) and expose as JSON
# SECURITY: Use a read-only API token and restrict network access via NetworkPolicy

import os
import json
import time
from typing import Optional
from fastapi import FastAPI, HTTPException, Query
import httpx

app = FastAPI(title="opcon-metrics-adapter", version="1.0.0")

OPCON_BASE = os.getenv('OPCON_BASE_URL', '').rstrip('/')
# Preferred: Long-lived application token (Solution Manager → External Token), otherwise service user credentials
OPCON_TOKEN = os.getenv('OPCON_TOKEN')
OPCON_USERNAME = os.getenv('OPCON_USERNAME')
OPCON_PASSWORD = os.getenv('OPCON_PASSWORD')
VERIFY_TLS = os.getenv('VERIFY_TLS','true').lower() not in ['false','0','no']
TIMEOUT = float(os.getenv('HTTP_TIMEOUT','10'))
DEFAULT_MACHINE_GROUP = os.getenv('DEFAULT_MACHINE_GROUP','lsam-aro')
DEFAULT_STATUSES = os.getenv('BACKLOG_STATUSES','Waiting,Queued').split(',')

# Cache token in memory when using username/password
_cached_token = None
_cached_token_expiry = 0.0

async def _get_token(client: httpx.AsyncClient) -> Optional[str]:
    global _cached_token, _cached_token_expiry
    if OPCON_TOKEN:
        return OPCON_TOKEN
    if OPCON_USERNAME and OPCON_PASSWORD:
        now = time.time()
        if _cached_token and now < _cached_token_expiry - 60:
            return _cached_token
        # Authenticate: POST /api/tokens → { token: "..." }
        url = f"{OPCON_BASE}/api/tokens"
        try:
            resp = await client.post(url, json={"username": OPCON_USERNAME, "password": OPCON_PASSWORD}, timeout=TIMEOUT)
            resp.raise_for_status()
            data = resp.json()
            token = data.get('token') or data.get('id')
            if not token:
                raise HTTPException(status_code=502, detail="OpCon auth did not return token")
            _cached_token = token
            # OpCon user tokens typically expire (implementation-specific). Set a conservative TTL of 15 minutes.
            _cached_token_expiry = now + 900
            return token
        except Exception as e:
            raise HTTPException(status_code=502, detail=f"Auth to OpCon failed: {e}")
    return None

async def _opcon_get(client: httpx.AsyncClient, path: str, params: dict=None):
    token = await _get_token(client)
    headers = {}
    if token:
        headers['Authorization'] = f"Token {token}"
    url = f"{OPCON_BASE}{path}"
    r = await client.get(url, headers=headers, params=params or {}, timeout=TIMEOUT)
    r.raise_for_status()
    return r.json()

@app.get("/healthz")
async def health():
    return {"ok": True}

@app.get("/v1/backlog")
async def backlog(machineGroup: Optional[str]=Query(None, description="OpCon Machine Group to filter"),
                  statuses: Optional[str]=Query(None, description="Comma-separated OpCon job statuses treated as backlog")):
    """
    Returns a simple JSON payload KEDA metrics-api scaler can parse:
      { "backlog": <int> }
    It sums the count of Daily Jobs in the given statuses for the machine group.

    NOTE: This implementation assumes OpCon REST API provides endpoints to count Daily Jobs by status
    and allows filtering by Machine or Machine Group. Adjust the path/params to your environment
    by editing the `_query_backlog` function below after verifying your OpCon Swagger UI at /api-doc/index.html.
    """
    mg = machineGroup or DEFAULT_MACHINE_GROUP
    status_list = [s.strip() for s in (statuses.split(',') if statuses else DEFAULT_STATUSES) if s.strip()]
    async with httpx.AsyncClient(verify=VERIFY_TLS) as client:
        count = await _query_backlog(client, mg, status_list)
    return {"backlog": int(count)}

async def _query_backlog(client: httpx.AsyncClient, machine_group: str, statuses: list[str]) -> int:
    """
    Example strategies to compute backlog:
    1) If your OpCon exposes an endpoint like /api/dailyjobs/count_by_status with filter args, use it directly.
    2) Otherwise, query /api/dailyjobs/count?status=... multiple times and sum.
    3) As a fallback, query /api/dailyjobs?status=...&page=... and count (less efficient).

    Update `endpoint` and `params` according to your environment.
    """
    total = 0
    # Strategy 1: hypothetical aggregated endpoint (verify in Swagger)
    try:
        endpoint = "/api/dailyjobs/count_by_status"  # Adjust if different in your OpCon version
        for st in statuses:
            params = {"status": st, "machineGroup": machine_group}
            data = await _opcon_get(client, endpoint, params=params)
            # Expect response like {"count": 123}
            c = data.get('count') if isinstance(data, dict) else None
            if c is None:
                # Try alternative field name
                c = data.get('value') if isinstance(data, dict) else None
            if c is None:
                # If API returns a list of items instead of a count
                if isinstance(data, list):
                    c = len(data)
            if c is None:
                # Last resort, try different endpoint below
                raise ValueError("Unsupported response for count_by_status")
            total += int(c)
        return total
    except Exception:
        # Strategy 2: query a generic count endpoint per status
        for st in statuses:
            endpoint = "/api/dailyjobs/count"
            params = {"status": st, "machineGroup": machine_group}
            try:
                data = await _opcon_get(client, endpoint, params=params)
                c = data.get('count') if isinstance(data, dict) else None
                if c is None:
                    raise ValueError("Unsupported response for count")
                total += int(c)
            except Exception:
                # Strategy 3: list and count (may be paginated)
                endpoint = "/api/dailyjobs"
                params = {"status": st, "machineGroup": machine_group, "page": 1, "pageSize": 1000}
                data = await _opcon_get(client, endpoint, params=params)
                if isinstance(data, dict) and 'total' in data:
                    total += int(data['total'])
                elif isinstance(data, list):
                    total += len(data)
                else:
                    raise HTTPException(status_code=502, detail="Unable to compute backlog from OpCon API response")
        return total

# Run via: uvicorn app.main:app --host 0.0.0.0 --port 8080
