const mongoose = require('mongoose');

const projectSchema = new mongoose.Schema({
  projectName: { type: String, required: true },

  assignedTo: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },

  assignedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },

  startDate: { type: Date, required: true },
  endDate: { type: Date, required: true },

  timesheetType: {
    type: String,
    enum: ['form'],
    default: 'form'
  },

  period: {
    type: String,
    enum: ['weekly', 'biweekly', 'monthly', 'semimonthly'],
  },

  lineManagerRequired: { type: Boolean, default: false },
  lineManagerName: { type: String },
  lineManagerEmail: { type: String },
}, { timestamps: true });

module.exports = mongoose.model('Project', projectSchema);