const mongoose = require('mongoose');

const timesheetSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  project: { type: mongoose.Schema.Types.ObjectId, ref: 'Project', required: true },
  period: { type: String, enum: ['weekly', 'biweekly', 'monthly'], required: true },
  format: { type: String, enum: ['form', 'file'], default: 'file' },

  entries: [
    {
      date: { type: Date, required: true },
      hours: { type: Number, default: 0 },
    }
  ],
  totalHours: { type: Number, default: 0 },

  fileUrl: { type: String },

  status: { type: String, enum: ['pending', 'approved', 'rejected'], default: 'pending' },
  rejectionReason: { type: String },

  submittedAt: { type: Date }
});

module.exports = mongoose.model('Timesheet', timesheetSchema);
