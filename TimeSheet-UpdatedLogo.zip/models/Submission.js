const mongoose = require('mongoose');

const submissionSchema = new mongoose.Schema({
  project: { type: mongoose.Schema.Types.ObjectId, ref: 'Project', required: true },
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  submissionType: { type: String, enum: ['file', 'form'], required: true },
  file: { filename: String, originalname: String },
  entries: [
    {
      date: String,
      day: String,
      hours: Number,
      notes: String
    }
  ],
  status: {
  type: String,
  enum: ['pending', 'approved', 'not approved', 'draft', 'saved'],
  default: 'pending'
},

submittedAt: {
  type: Date,
  default: Date.now
},

dueDate: {
  type: Date,
  required: true
},

isSubmitted: {
  type: Boolean,
  default: false
},

lineManagerRequired: {
  type: Boolean,
  default: false
},
  lineManagerToken: { type: String },

  decisionNotes: { type: String },

  adminEdited: { type: Boolean, default: false },
  adminEditNote: { type: String },
  editedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  editedAt: { type: Date }
});



const Submission = mongoose.model('Submission', submissionSchema);

module.exports = Submission;