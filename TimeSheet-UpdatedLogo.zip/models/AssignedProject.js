const mongoose = require('mongoose');

const assignedProjectSchema = new mongoose.Schema({
  projectName: { type: String, required: true },
  assignedTo: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  startDate: { type: Date, required: true },
  endDate: { type: Date, required: true },
  isSubmitted: { type: Boolean, default: false }
}, {
  timestamps: true
});

module.exports = mongoose.model('AssignedProject', assignedProjectSchema);