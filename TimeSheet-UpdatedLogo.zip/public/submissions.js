document.addEventListener('DOMContentLoaded', async () => {
  const container = document.getElementById('submissionsContainer');
  const token = localStorage.getItem('token');

  if (!token) {
    container.innerHTML = '<p style="color:red;">No token found. Please log in again.</p>';
    return;
  }

  try {
    const res = await fetch('/api/submissions', {
      headers: { Authorization: `Bearer ${token}` }
    });
    if (!res.ok) throw new Error('Failed to load submissions');

    const submissions = await res.json();
    console.log('Fetched submissions:', submissions);

    if (submissions.length === 0) {
      container.innerHTML = '<p>No submissions found.</p>';
      return;
    }

    container.innerHTML = '';

    submissions.sort((a, b) => new Date(b.submittedAt) - new Date(a.submittedAt));

    submissions.forEach(sub => {
      const submissionDiv = document.createElement('div');
      submissionDiv.className = 'submission';
      submissionDiv.style.position = 'relative';
      submissionDiv.style.paddingTop = '30px';

      const fileUrl = `/uploads/${sub.file?.filename || ''}`;

      let totalHours = 0;
      let duration = 'N/A';
      if (sub.submissionType === 'form' && Array.isArray(sub.entries) && sub.entries.length > 0) {
        totalHours = sub.entries.reduce((sum, e) => sum + (Number(e.hours) || 0), 0);
        const dates = sub.entries.map(e => e.date).filter(Boolean).sort();
        if (dates.length > 0) duration = `${dates[0]} to ${dates[dates.length - 1]}`;
      }

      submissionDiv.innerHTML = `
        <p><strong>User:</strong> ${sub.user?.name || 'Unknown'} (${sub.user?.email || ''})</p>
        <p><strong>Project:</strong> ${sub.project?.projectName || 'N/A'}</p>
        ${sub.submissionType === 'form' && Array.isArray(sub.entries) && sub.entries.length > 0 ? `
        <p><strong>Total Hours:</strong> ${totalHours.toFixed(2)}</p>
        <p><strong>Duration:</strong> ${duration}</p>
        ` : ''}
        <p><strong>Date:</strong> ${new Date(sub.submittedAt).toLocaleString()}</p>
        <p><strong>Status:</strong> 
          <span style="color: ${
            sub.status === 'approved' ? 'green' :
            sub.status === 'not approved' ? 'red' : 'orange'
          }">${sub.status}</span>
        </p>
        ${sub.file ? `<p><a href="${fileUrl}" target="_blank">Download File</a></p>` : ''}
        ${sub.adminEdited ? `<p style="color:#8a6d00;"><em>Hours corrected by admin${sub.editedAt ? ' on ' + new Date(sub.editedAt).toLocaleString() : ''}${sub.adminEditNote ? `: "${sub.adminEditNote}"` : ''}</em></p>` : ''}
      `;


      if (sub.submissionType === 'form' && Array.isArray(sub.entries) && sub.entries.length > 0) {
        const viewFormBtn = document.createElement('button');
        viewFormBtn.textContent = 'View Form';
        viewFormBtn.style.marginLeft = '5px';
        viewFormBtn.onclick = () => {
          window.location.href = `form-viewer.html?submissionId=${sub._id}`;
        };
        submissionDiv.appendChild(viewFormBtn);

        const editHoursBtn = document.createElement('button');
        editHoursBtn.textContent = 'Edit Hours';
        editHoursBtn.style.marginLeft = '5px';
        editHoursBtn.onclick = () => toggleHoursEditor(submissionDiv, sub);
        submissionDiv.appendChild(editHoursBtn);
      }

      const deleteBtn = document.createElement('button');
      deleteBtn.className = 'delete-btn';
      deleteBtn.title = 'Delete submission';
      deleteBtn.textContent = '×';
      deleteBtn.onclick = async () => {
        if (!confirm('Are you sure you want to delete this submission?')) return;

        try {
          const token = localStorage.getItem('token');
          const res = await fetch(`/api/submissions/${sub._id}`, {
            method: 'DELETE',
            headers: { Authorization: `Bearer ${token}` }
          });

          if (!res.ok) {
            let errorMsg = 'Unknown error';
            try {
              const data = await res.json();
              errorMsg = data.message || errorMsg;
            } catch {
              errorMsg = await res.text();
            }
            alert('Failed to delete: ' + errorMsg);
            return;
          }

          alert('Submission deleted.');
          submissionDiv.remove();
        } catch (err) {
          alert('Error deleting submission.');
          console.error(err);
        }
      };

      const requiresLM = (sub.lineManagerRequired === true) ||
                         (sub.project && sub.project.lineManagerRequired === true);

if (requiresLM) {
  const lmNotice = document.createElement('div');
  lmNotice.style.backgroundColor = '#e0f0ff';
  lmNotice.style.border = '1px solid #007bff';
  lmNotice.style.borderRadius = '6px';
  lmNotice.style.padding = '8px 12px';
  lmNotice.style.marginTop = '10px';
  lmNotice.style.fontWeight = 'bold';
  lmNotice.style.color = '#007bff';
  lmNotice.style.display = 'inline-block';
  lmNotice.textContent = 'Line Manager Approval Required';

  submissionDiv.appendChild(lmNotice);
}
 else {
        const approveBtn = document.createElement('button');
        approveBtn.textContent = 'Approve';
        approveBtn.onclick = () => handleDecision(sub._id, 'approve');

        const rejectBtn = document.createElement('button');
        rejectBtn.textContent = 'Reject';
        rejectBtn.onclick = () => {
  if (rejectBtn.nextSibling && rejectBtn.nextSibling.className === 'reasonDiv') return;

  const reasonDiv = document.createElement('div');
  reasonDiv.className = 'reasonDiv';
  reasonDiv.style.marginTop = '10px';

  const reasonInput = document.createElement('textarea');
  reasonInput.placeholder = 'Enter reason for rejection';
  reasonInput.rows = 3;
  reasonInput.style.width = '300px';
  reasonInput.style.marginRight = '10px';

  const submitBtn = document.createElement('button');
  submitBtn.textContent = 'Submit';
  submitBtn.style.marginRight = '5px';
  submitBtn.onclick = () => {
    const reason = reasonInput.value.trim();
    if (!reason) {
      alert('Reason is required to reject.');
      return;
    }
    handleDecision(sub._id, 'reject', reason);
  };

  const cancelBtn = document.createElement('button');
  cancelBtn.textContent = 'Cancel';
  cancelBtn.onclick = () => reasonDiv.remove();

  reasonDiv.appendChild(reasonInput);
  reasonDiv.appendChild(submitBtn);
  reasonDiv.appendChild(cancelBtn);

  submissionDiv.appendChild(reasonDiv);
};


        submissionDiv.append(approveBtn, rejectBtn);
      }

      submissionDiv.append(deleteBtn, document.createElement('hr'));
      container.appendChild(submissionDiv);
    });

  } catch (err) {
    console.error(err);
    container.innerHTML = '<p style="color:red;">Error loading submissions.</p>';
  }
});

async function handleDecision(submissionId, action, reason = '') {
  const token = localStorage.getItem('token');

  try {
    let bodyData = null;
    let headers = { Authorization: `Bearer ${token}` };

    if (action === 'reject') {
      if (!reason.trim()) {
        alert('Reason is required to reject.');
        return;
      }
      bodyData = JSON.stringify({ reason });
      headers['Content-Type'] = 'application/json';
    }

    const res = await fetch(
      `/api/submissions/submit/${submissionId}/${action}`,
      { method: 'PUT', headers, body: bodyData }
    );

    const result = await res.json();
    if (!res.ok) throw new Error(result.message || 'Action failed');

    alert(
      action === 'reject'
        ? 'Submission rejected with note sent to user.'
        : 'Submission approved'
    );
    location.reload();
  } catch (err) {
    console.error('Error processing decision:', err);
    alert(err.message);
  }
}


function toggleHoursEditor(submissionDiv, sub) {
  const existing = submissionDiv.querySelector('.hours-editor');
  if (existing) {
    existing.remove();
    return;
  }

  const editorDiv = document.createElement('div');
  editorDiv.className = 'hours-editor';
  editorDiv.style.marginTop = '10px';
  editorDiv.style.border = '1px solid #ddd';
  editorDiv.style.borderRadius = '6px';
  editorDiv.style.padding = '10px';
  editorDiv.style.backgroundColor = '#fafafa';

  let rowsHTML = '';
  sub.entries.forEach((entry, i) => {
    rowsHTML += `
      <tr>
        <td>${entry.date || ''}</td>
        <td>${entry.day || ''}</td>
        <td><input type="number" min="0" max="24" step="0.25" data-index="${i}" class="hoursEditInput" value="${entry.hours}" style="width:70px;" /></td>
        <td>${entry.notes || ''}</td>
      </tr>
    `;
  });

  editorDiv.innerHTML = `
    <p style="font-weight:bold;">Correct entered hours (0–24 per day):</p>
    <table style="width:100%; border-collapse: collapse;">
      <thead>
        <tr><th>Date</th><th>Day</th><th>Hours</th><th>Notes</th></tr>
      </thead>
      <tbody>${rowsHTML}</tbody>
    </table>
    <label style="display:block; margin-top:10px; font-weight:bold;">Note to employee (required):</label>
    <textarea class="hoursEditNote" rows="2" style="width:100%;" placeholder="Explain why the hours were changed, e.g. 'Corrected Tuesday from 40 to 8 hours.'"></textarea>
    <div style="margin-top:8px;">
      <button type="button" class="saveHoursBtn">Save Corrected Hours</button>
      <button type="button" class="cancelHoursBtn">Cancel</button>
      <span class="hoursEditStatus" style="margin-left:10px;"></span>
    </div>
  `;

  editorDiv.querySelector('.cancelHoursBtn').onclick = () => editorDiv.remove();
  editorDiv.querySelector('.saveHoursBtn').onclick = () => saveEditedHours(sub, editorDiv);

  submissionDiv.appendChild(editorDiv);
}

async function saveEditedHours(sub, editorDiv) {
  const token = localStorage.getItem('token');
  const statusSpan = editorDiv.querySelector('.hoursEditStatus');
  const note = editorDiv.querySelector('.hoursEditNote').value.trim();

  if (!note) {
    statusSpan.textContent = 'A note to the employee is required before saving.';
    statusSpan.style.color = 'red';
    return;
  }

  const inputs = editorDiv.querySelectorAll('.hoursEditInput');
  const updatedEntries = sub.entries.map((entry, i) => {
    const input = Array.from(inputs).find(inp => Number(inp.dataset.index) === i);
    const hours = input ? parseFloat(input.value) : entry.hours;
    return { ...entry, hours: isNaN(hours) ? 0 : hours };
  });

  const invalid = updatedEntries.find(e => e.hours < 0 || e.hours > 24);
  if (invalid) {
    statusSpan.textContent = 'Hours must be between 0 and 24.';
    statusSpan.style.color = 'red';
    return;
  }

  try {
    const res = await fetch(`/api/submissions/${sub._id}/entries`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`
      },
      body: JSON.stringify({ entries: updatedEntries, note })
    });

    const result = await res.json();
    if (!res.ok) throw new Error(result.message || 'Failed to save corrected hours');

    statusSpan.textContent = 'Saved!';
    statusSpan.style.color = 'green';
    setTimeout(() => location.reload(), 600);
  } catch (err) {
    console.error('Error saving corrected hours:', err);
    statusSpan.textContent = err.message;
    statusSpan.style.color = 'red';
  }
}