document.getElementById('signUpForm').addEventListener('submit', async function (e) {
  e.preventDefault();

  const name = document.getElementById('name').value;
  const email = document.getElementById('email').value;
  const password = document.getElementById('password').value;
  const messageDiv = document.getElementById('message');

  try {
    const res = await fetch('/api/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, email, password })
    });

    const data = await res.json();

    if (res.ok) {
      messageDiv.style.color = 'green';
      messageDiv.textContent = 'Registration successful. Redirecting...';
      setTimeout(() => {
        window.location.href = 'timesheet.html';
      }, 1500);
    } else {
      messageDiv.style.color = 'red';
      messageDiv.textContent = `${data.message || 'Registration Failed'}`;
    }
  } catch (err) {
    messageDiv.style.color = 'red';
    messageDiv.textContent = 'Error, please try again.';
    console.error(err);
  }
});