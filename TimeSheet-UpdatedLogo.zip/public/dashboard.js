const token = localStorage.getItem('token');
const user = JSON.parse(localStorage.getItem('user'));
const message = document.getElementById('message');
const projectsDiv = document.getElementById('assigned-projects');

async function loadProjects() {
  const res = await fetch(`/api/projects/user/${user.id}`, {
    headers: { Authorization: `Bearer ${token}` }
  });
  const data = await res.json();

  if (res.ok) {
    if (data.message) {
      projectsDiv.innerHTML = `<p>${data.message}</p>`;
    } else {
      projectsDiv.innerHTML = data.map(p => `
        <div>
          <h4>${p.projectName}</h4>
          <p>${new Date(p.startDate).toLocaleDateString()} → ${new Date(p.endDate).toLocaleDateString()}</p>
        </div>
      `).join('');
    }
  } else {
    projectsDiv.innerHTML = '<p>Error loading projects</p>';
  }
}

async function submitTimesheet() {
  const file = document.getElementById('fileUpload').files[0];
  if (!file) return;

  const formData = new FormData();
  formData.append('file', file);
  formData.append('userId', user.id);

  const res = await fetch('/api/upload', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`
    },
    body: formData
  });

  const data = await res.json();
  message.textContent = res.ok ? 'File uploaded!' : 'Upload failed';
  message.style.color = res.ok ? 'green' : 'red';
}

function logout() {
  localStorage.removeItem('token');
  localStorage.removeItem('user');
  window.location.href = 'timesheet.html';
}

loadProjects();
