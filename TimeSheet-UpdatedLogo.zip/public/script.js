document.addEventListener("DOMContentLoaded", () => {
  const timesheetContainer = document.getElementById("timesheetContainer");
  if (!timesheetContainer) return;

  const token = localStorage.getItem("token");
  const user = JSON.parse(localStorage.getItem("user"));

  if (!token || !user) {
    window.location.href = "timesheet.html";
    return;
  }

  async function fetchAssignedTimesheet() {
    try {
      const res = await fetch(`/api/timesheet/assigned/${user._id}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await res.json();

      if (!res.ok) throw new Error(data.message || "Failed to fetch timesheet");

      generateTimesheet(data.format);
    } catch (err) {
      console.error("Error fetching assigned timesheet:", err);
      timesheetContainer.innerHTML = "<p>No timesheet assigned.</p>";
    }
  }

  function generateTimesheet(format) {
    let startDate, endDate;

    const today = new Date();

    if (format === "weekly") {
      const day = today.getDay();
      const diff = today.getDate() - day + (day === 0 ? -6 : 1);
      startDate = new Date(today.setDate(diff));
      endDate = new Date(startDate);
      endDate.setDate(startDate.getDate() + 6);
    } else if (format === "bi-weekly") {
      const day = today.getDate();
      if (day <= 15) {
        startDate = new Date(today.getFullYear(), today.getMonth(), 1);
        endDate = new Date(today.getFullYear(), today.getMonth(), 15);
      } else {
        startDate = new Date(today.getFullYear(), today.getMonth(), 16);
        endDate = new Date(today.getFullYear(), today.getMonth() + 1, 0);
      }
    } else if (format === "monthly") {
      startDate = new Date(today.getFullYear(), today.getMonth(), 1);
      endDate = new Date(today.getFullYear(), today.getMonth() + 1, 0);
    }

    const rows = [];
    const loopDate = new Date(startDate);
    while (loopDate <= endDate) {
      rows.push(
        `<tr>
          <td>${loopDate.toDateString()}</td>
          <td><input type="number" class="hoursInput" data-date="${loopDate.toISOString().split("T")[0]}" min="0" max="24" /></td>
        </tr>`
      );
      loopDate.setDate(loopDate.getDate() + 1);
    }

    timesheetContainer.innerHTML = `
      <h2>${format.charAt(0).toUpperCase() + format.slice(1)} Timesheet</h2>
      <form id="timesheetForm">
        <table border="1" cellpadding="5">
          <thead>
            <tr><th>Date</th><th>Hours Worked</th></tr>
          </thead>
          <tbody>
            ${rows.join("")}
          </tbody>
        </table>
        <p><strong>Total Hours: <span id="totalHours">0</span></strong></p>
        <label>Optional PDF Upload: <input type="file" id="pdfUpload" accept="application/pdf" /></label>
        <br><br>
        <button type="submit">Submit Timesheet</button>
      </form>
    `;

    attachTimesheetEvents();
  }

  function attachTimesheetEvents() {
    const inputs = document.querySelectorAll(".hoursInput");
    const totalEl = document.getElementById("totalHours");
    const form = document.getElementById("timesheetForm");

    inputs.forEach(input => {
      input.addEventListener("input", () => {
        let total = 0;
        inputs.forEach(i => {
          total += parseFloat(i.value) || 0;
        });
        totalEl.textContent = total;
      });
    });

    form.addEventListener("submit", async (e) => {
      e.preventDefault();

      const entries = [];
      inputs.forEach(input => {
        entries.push({
          date: input.dataset.date,
          hours: parseFloat(input.value) || 0
        });
      });

      const total = entries.reduce((sum, e) => sum + e.hours, 0);

      const formData = new FormData();
      formData.append("entries", JSON.stringify(entries));
      formData.append("totalHours", total);

      const pdfFile = document.getElementById("pdfUpload").files[0];
      if (pdfFile) {
        formData.append("pdf", pdfFile);
      }

      try {
        const res = await fetch(`/api/timesheet/submit/${user._id}`, {
          method: "POST",
          headers: { Authorization: `Bearer ${token}` },
          body: formData
        });
        const data = await res.json();

        if (res.ok) {
          alert("Timesheet submitted successfully!");
        } else {
          alert(`Error: ${data.message}`);
        }
      } catch (err) {
        console.error("Timesheet submit error:", err);
        alert("Something went wrong submitting your timesheet.");
      }
    });
  }

  fetchAssignedTimesheet();
});
