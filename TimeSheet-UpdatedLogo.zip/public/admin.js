const token = localStorage.getItem('token');

async function loadUsers() {
  const dropdown = document.getElementById('userSelect');
  const userList = document.getElementById('userList');
  dropdown.innerHTML = '<option disabled selected>Loading users...</option>';
  userList.innerHTML = 'Loading users...';

  try {
    const res = await fetch('/api/users/all-users', {
      headers: { Authorization: `Bearer ${token}` }
    });

    const users = await res.json();

    if (!Array.isArray(users)) {
      console.error("Expected an array of users but got:", users);
      dropdown.innerHTML = '<option disabled>Error loading users</option>';
      userList.innerHTML = 'Error loading users';
      return;
    }

    dropdown.innerHTML = '<option disabled selected>Select a user</option>';
    userList.innerHTML = '';

    users.forEach(user => {
      const option = document.createElement('option');
      option.value = user._id;
      option.textContent = `${user.name} (${user.email})`;
      dropdown.appendChild(option);

      const div = document.createElement('div');
      div.className = 'user-entry';
      div.style.border = "1px solid #ccc";
      div.style.padding = "8px";
      div.style.margin = "5px 0";
      div.style.borderRadius = "5px";

      div.innerHTML = `
        <strong>${user.name}</strong><br>
        <small>${user.email}</small><br>
        <button class="deleteUserBtn" data-id="${user._id}">Delete</button>
      `;

      userList.appendChild(div);
    });

    document.querySelectorAll('.deleteUserBtn').forEach(btn => {
      btn.addEventListener('click', () => {
        const userId = btn.getAttribute('data-id');
        removeUser(userId);
      });
    });

  } catch (err) {
    console.error('Error loading users:', err);
    dropdown.innerHTML = '<option disabled>Error loading users</option>';
    userList.innerHTML = 'Error loading users';
  }
}

async function removeUser(userId) {
  if (!confirm('Are you sure you want to delete this user?')) return;

  try {
    const res = await fetch(`/api/users/delete/${userId}`, {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${token}` }
    });

    if (res.ok) {
      alert('User deleted');
      loadUsers();
    } else {
      const data = await res.json();
      alert('Failed to delete user: ' + (data.message || 'Unknown error'));
    }
  } catch (err) {
    console.error('Error deleting user:', err);
    alert('Server error deleting user');
  }
}

document.getElementById('toggleUserBox').addEventListener('click', () => {
  const userBox = document.getElementById('userBox');
  userBox.style.display = (userBox.style.display === 'none' || userBox.style.display === '') ? 'block' : 'none';
});


function fmt(date) {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

function getWeekRange(anyDateStr) {
  const anchor = new Date(anyDateStr + 'T00:00:00');
  const day = anchor.getDay();
  const diffToMonday = day === 0 ? -6 : 1 - day;
  const monday = new Date(anchor);
  monday.setDate(anchor.getDate() + diffToMonday);
  const sunday = new Date(monday);
  sunday.setDate(monday.getDate() + 6);
  return { start: monday, end: sunday };
}

function getBiweeklyRange(startStr) {
  const start = new Date(startStr + 'T00:00:00');
  const end = new Date(start);
  end.setDate(start.getDate() + 13);
  return { start, end };
}

function getMonthRange(monthStr) {
  const [y, m] = monthStr.split('-').map(Number);
  const start = new Date(y, m - 1, 1);
  const end = new Date(y, m, 0);
  return { start, end };
}

function getSemimonthlyRange(monthStr, half) {
  const [y, m] = monthStr.split('-').map(Number);
  if (half === 'first') {
    return { start: new Date(y, m - 1, 1), end: new Date(y, m - 1, 15) };
  }
  const lastDay = new Date(y, m, 0);
  return { start: new Date(y, m - 1, 16), end: lastDay };
}


const formatFieldGroups = {
  weekly: 'weeklyDateFields',
  biweekly: 'biweeklyDateFields',
  monthly: 'monthlyDateFields',
  semimonthly: 'semimonthlyDateFields',
};

function updateFormatFieldVisibility() {
  const selected = document.getElementById('timesheetForm').value;
  Object.entries(formatFieldGroups).forEach(([key, id]) => {
    document.getElementById(id).style.display = key === selected ? 'block' : 'none';
  });
  updateRangePreview();
}

function updateRangePreview() {
  const selected = document.getElementById('timesheetForm').value;

  if (selected === 'weekly') {
    const val = document.getElementById('weekPicker').value;
    const preview = document.getElementById('weeklyRangePreview');
    if (val) {
      const { start, end } = getWeekRange(val);
      preview.textContent = `Week: ${start.toDateString()} – ${end.toDateString()}`;
    } else {
      preview.textContent = '';
    }
  } else if (selected === 'biweekly') {
    const val = document.getElementById('biweeklyStart').value;
    const preview = document.getElementById('biweeklyRangePreview');
    if (val) {
      const { start, end } = getBiweeklyRange(val);
      preview.textContent = `Period: ${start.toDateString()} – ${end.toDateString()}`;
    } else {
      preview.textContent = '';
    }
  } else if (selected === 'monthly') {
    const val = document.getElementById('monthPicker').value;
    const preview = document.getElementById('monthlyRangePreview');
    if (val) {
      const { start, end } = getMonthRange(val);
      preview.textContent = `Period: ${start.toDateString()} – ${end.toDateString()}`;
    } else {
      preview.textContent = '';
    }
  } else if (selected === 'semimonthly') {
    const val = document.getElementById('semimonthlyMonth').value;
    const half = document.getElementById('semimonthlyHalf').value;
    const preview = document.getElementById('semimonthlyRangePreview');
    if (val) {
      const { start, end } = getSemimonthlyRange(val, half);
      preview.textContent = `Period: ${start.toDateString()} – ${end.toDateString()}`;
    } else {
      preview.textContent = '';
    }
  }
}

['weekPicker', 'biweeklyStart', 'monthPicker', 'semimonthlyMonth', 'semimonthlyHalf'].forEach(id => {
  document.getElementById(id).addEventListener('change', updateRangePreview);
});

document.getElementById('timesheetForm').addEventListener('change', updateFormatFieldVisibility);
updateFormatFieldVisibility();

function computeStartEndDates() {
  const selected = document.getElementById('timesheetForm').value;

  if (selected === 'weekly') {
    const val = document.getElementById('weekPicker').value;
    if (!val) return null;
    const { start, end } = getWeekRange(val);
    return { startDate: fmt(start), endDate: fmt(end) };
  }

  if (selected === 'biweekly') {
    const val = document.getElementById('biweeklyStart').value;
    if (!val) return null;
    const { start, end } = getBiweeklyRange(val);
    return { startDate: fmt(start), endDate: fmt(end) };
  }

  if (selected === 'monthly') {
    const val = document.getElementById('monthPicker').value;
    if (!val) return null;
    const { start, end } = getMonthRange(val);
    return { startDate: fmt(start), endDate: fmt(end) };
  }

  if (selected === 'semimonthly') {
    const val = document.getElementById('semimonthlyMonth').value;
    const half = document.getElementById('semimonthlyHalf').value;
    if (!val) return null;
    const { start, end } = getSemimonthlyRange(val, half);
    return { startDate: fmt(start), endDate: fmt(end) };
  }

  return null;
}


let currentExistingProject = null;

async function checkExistingAssignment(userId) {
  const notice = document.getElementById('existingAssignmentNotice');
  const replaceWrap = document.getElementById('replaceExistingWrap');
  const replaceCheckbox = document.getElementById('replaceExisting');
  notice.innerHTML = '';
  replaceWrap.style.display = 'none';
  replaceCheckbox.checked = false;
  currentExistingProject = null;

  if (!userId) return;

  try {
    const res = await fetch(`/api/projects/by-user/${userId}`, {
      headers: { Authorization: `Bearer ${token}` }
    });
    if (!res.ok) return;
    const project = await res.json();
    if (!project) return;

    currentExistingProject = project;
    notice.innerHTML = `
      <div style="background:#fff3cd;border:1px solid #ffc107;border-radius:6px;padding:10px;margin:10px 0;">
        This user already has an assigned project: <strong>${project.projectName}</strong>
        (${project.period || project.timesheetType}).
        <button type="button" id="removeAssignmentBtn" style="margin-left:8px;">Remove Assignment</button>
      </div>
    `;
    replaceWrap.style.display = 'block';

    document.getElementById('removeAssignmentBtn').addEventListener('click', async () => {
      if (!confirm(`Remove "${project.projectName}" from this user?`)) return;
      const delRes = await fetch(`/api/projects/${project._id}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` }
      });
      if (delRes.ok) {
        alert('Assignment removed. You can now assign a new project.');
        checkExistingAssignment(userId);
      } else {
        alert('Failed to remove assignment.');
      }
    });
  } catch (err) {
    console.error('Error checking existing assignment:', err);
  }
}

document.getElementById('userSelect').addEventListener('change', function () {
  checkExistingAssignment(this.value);
});


document.getElementById('assignProjectForm').addEventListener('submit', async e => {
  e.preventDefault();

  const userId = document.getElementById('userSelect').value;
  const projectName = document.getElementById('projectName').value;
  const timesheetForm = document.getElementById('timesheetForm').value;

  const lineManagerRequired = document.getElementById('lineManagerRequired').checked;
  const lineManagerName = lineManagerRequired ? document.getElementById('lineManagerName').value : null;
  const lineManagerEmail = lineManagerRequired ? document.getElementById('lineManagerEmail').value : null;

  const replaceExisting = document.getElementById('replaceExisting').checked;

  const statusDiv = document.getElementById('status');

  const dates = computeStartEndDates();
  if (!dates) {
    statusDiv.textContent = 'Please pick the date(s) for the selected timesheet format.';
    statusDiv.style.color = 'red';
    return;
  }

  try {
    const res = await fetch('/api/projects/assign', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({
        userId, projectName, startDate: dates.startDate, endDate: dates.endDate, timesheetForm,
        lineManagerRequired,
        lineManagerName,
        lineManagerEmail,
        replaceExisting
      })
    });

    const data = await res.json();

    if (res.ok) {
      statusDiv.textContent = 'Project assigned successfully.';
      statusDiv.style.color = 'green';
      e.target.reset();
      document.getElementById('lineManagerFields').style.display = 'none';
      document.getElementById('existingAssignmentNotice').innerHTML = '';
      document.getElementById('replaceExistingWrap').style.display = 'none';
      ['weeklyRangePreview', 'biweeklyRangePreview', 'monthlyRangePreview', 'semimonthlyRangePreview'].forEach(id => {
        document.getElementById(id).textContent = '';
      });
      updateFormatFieldVisibility();
    } else if (res.status === 409) {
      statusDiv.textContent = data.error || 'This user already has a project assigned.';
      statusDiv.style.color = 'red';
      document.getElementById('replaceExistingWrap').style.display = 'block';
    } else {
      statusDiv.textContent = data.error || 'Assignment failed.';
      statusDiv.style.color = 'red';
    }
  } catch (err) {
    console.error('Error assigning project:', err);
    statusDiv.textContent = 'Server error. Try again later.';
    statusDiv.style.color = 'red';
  }
});

document.getElementById('lineManagerRequired').addEventListener('change', function() {
  document.getElementById('lineManagerFields').style.display = this.checked ? 'block' : 'none';
});


function logout() {
  localStorage.removeItem('token');
  localStorage.removeItem('user');
  window.location.href = 'timesheet.html';
}

document.addEventListener('DOMContentLoaded', loadUsers);