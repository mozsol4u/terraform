document.addEventListener('DOMContentLoaded', async () => {
  const container = document.getElementById('formTableContainer');
  const submissionInfo = document.getElementById('submissionInfo');

  const params = new URLSearchParams(window.location.search);
  const submissionId = params.get('submissionId');
  const token = params.get('token');

  if (!submissionId) {
    container.innerHTML = '<p style="color:red;">No submission ID provided.</p>';
    return;
  }

  try {
    const res = await fetch(`/api/submissions/public/api/form-viewer/${submissionId}`);
    if (!res.ok) {
      container.innerHTML = `<p style="color:red;">Failed to load submission. Status: ${res.status}</p>`;
      return;
    }

    const sub = await res.json();

    submissionInfo.innerHTML = `
      <strong>User:</strong> ${sub.user?.name || 'Unknown'} (${sub.user?.email || ''})<br>
      <strong>Project:</strong> ${sub.project?.projectName || 'N/A'}<br>
      <strong>Status:</strong> ${sub.status || 'pending'}<br>
      <strong>Submitted At:</strong> ${new Date(sub.submittedAt).toLocaleString()}
    `;

    if (!sub.entries || !Array.isArray(sub.entries) || sub.entries.length === 0) {
      container.innerHTML = '<p>No form entries found.</p>';
      return;
    }

    let totalHours = 0;
    let tableHTML = `<table>
      <thead>
        <tr>
          <th>Date</th>
          <th>Day</th>
          <th>Hours Worked</th>
          <th>Notes</th>
        </tr>
      </thead>
      <tbody>`;

    sub.entries.forEach(entry => {
      tableHTML += `
        <tr>
          <td>${entry.date}</td>
          <td>${entry.day || ''}</td>
          <td>${entry.hours}</td>
          <td>${entry.notes || ''}</td>
        </tr>
      `;
      totalHours += parseFloat(entry.hours) || 0;
    });

    tableHTML += `
      <tr>
        <td colspan="2" style="text-align:right; font-weight:bold;">Total Hours</td>
        <td colspan="2" style="font-weight:bold;">${totalHours.toFixed(2)}</td>
      </tr>
    `;

    tableHTML += `</tbody></table>`;

    container.innerHTML = tableHTML;

    const requiresLM = !!sub.lineManagerRequired;
    if (requiresLM && token) {
      const actionsDiv = document.createElement('div');
      actionsDiv.style.marginTop = "20px";

      const approveBtn = document.createElement('button');
      approveBtn.textContent = "Approve";
      approveBtn.style.marginRight = "10px";
      approveBtn.onclick = () => lineManagerDecision(submissionId, "approved", token);

      const rejectBtn = document.createElement('button');
      rejectBtn.textContent = "Reject";
      rejectBtn.style.marginRight = "8px";
      rejectBtn.onclick = () => {
        const reason = prompt("Enter reason for rejection:") || "";
        lineManagerDecision(submissionId, "not approved", token, reason);
      };

      actionsDiv.appendChild(approveBtn);
      actionsDiv.appendChild(rejectBtn);
      container.appendChild(actionsDiv);
    }

  } catch (err) {
    console.error(err);
    container.innerHTML = '<p style="color:red;">Error loading submission.</p>';
  }
});

async function downloadTimesheet(jsonData) {
  const response = await fetch('/api/submissions/download-pdf', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(jsonData)
  });

  const blob = await response.blob();
  const url = window.URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = 'timesheet.pdf';
  link.click();
  window.URL.revokeObjectURL(url);
}


async function lineManagerDecision(submissionId, action, token, reason = '') {
  try {
    const body = { token, action };

    if (reason) body.reason = reason;

    const res = await fetch(
      `/api/submissions/line-manager/action/${submissionId}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body)
      }
    );

    const result = await res.json();
    if (!res.ok) {
      alert(result.message || "Action failed");
      return;
    }

    alert(
      action === 'approved'
        ? 'Submission approved successfully.'
        : 'Submission not approved successfully.'
    );
    location.reload();
  } catch (err) {
    console.error("Error sending decision:", err);
    alert("Error sending decision.");
  }
}
