document.addEventListener('DOMContentLoaded', async () => {
  const container = document.getElementById('formTableContainer');
  const submissionInfo = document.getElementById('submissionInfo');
  const downloadBtn = document.getElementById('downloadBtn');
  const backBtn = document.getElementById('backBtn');

  const isAdmin = localStorage.getItem('isAdmin') === 'true';
  if (backBtn) {
    backBtn.href = isAdmin ? 'submissions.html' : 'dashboard.html';
  }

  const params = new URLSearchParams(window.location.search);
  const submissionId = params.get('submissionId');
  const token = params.get('token');

  if (!submissionId) {
    container.innerHTML = '<p style="color:red;">No submission ID provided.</p>';
    return;
  }

  try {
    const res = await fetch(
      `/api/submissions/public/form-viewer/${submissionId}?token=${token || ''}`
    );

    if (!res.ok) {
      container.innerHTML = `<p style="color:red;">Failed to load submission. Status: ${res.status}</p>`;
      return;
    }

    const sub = await res.json();

    submissionInfo.innerHTML = `
      <strong>User:</strong> ${sub.user?.name || 'Unknown'} (${sub.user?.email || ''})<br>
      <strong>Project:</strong> ${sub.project?.projectName || 'N/A'}<br>
      <strong>Status:</strong> ${sub.status || 'pending'}<br>
      <strong>Submitted At:</strong> ${new Date(sub.submittedAt).toLocaleString()}
    `;

    if (!sub.entries || !Array.isArray(sub.entries) || sub.entries.length === 0) {
      container.innerHTML = '<p>No form entries found.</p>';
      return;
    }

    let totalHours = 0;
    let tableHTML = `<table id="timesheetTable">
      <thead>
        <tr>
          <th>Date</th>
          <th>Day</th>
          <th>Hours Worked</th>
          <th>Notes</th>
        </tr>
      </thead>
      <tbody>`;

    sub.entries.forEach(entry => {
      tableHTML += `
        <tr>
          <td>${entry.date}</td>
          <td>${entry.day || ''}</td>
          <td>${entry.hours}</td>
          <td>${entry.notes || ''}</td>
        </tr>
      `;
      totalHours += parseFloat(entry.hours) || 0;
    });

    tableHTML += `
      <tr>
        <td colspan="2" style="text-align:right; font-weight:bold;">Total Hours</td>
        <td colspan="2" style="font-weight:bold;">${totalHours.toFixed(2)}</td>
      </tr>
    `;

    tableHTML += `</tbody></table>`;
    container.innerHTML = tableHTML;

    if (downloadBtn) {
      downloadBtn.style.display = 'inline-block';
      downloadBtn.onclick = () => generatePDF(sub);
    }

    if (sub.lineManagerRequired && sub.tokenValid && token) {
      const actionsDiv = document.createElement('div');
      actionsDiv.style.marginTop = "20px";

      const approveBtn = document.createElement('button');
      approveBtn.textContent = "Approve";
      approveBtn.style.marginRight = "10px";
      approveBtn.onclick = () => lineManagerDecision(submissionId, "approved", token);

      const rejectBtn = document.createElement('button');
      rejectBtn.textContent = "Reject";
      rejectBtn.onclick = () => showRejectReasonBox(actionsDiv, submissionId, token);

      actionsDiv.appendChild(approveBtn);
      actionsDiv.appendChild(rejectBtn);
      container.appendChild(actionsDiv);
    }
  } catch (err) {
    console.error(err);
    container.innerHTML = '<p style="color:red;">Error loading submission.</p>';
  }
});

function showRejectReasonBox(actionsDiv, submissionId, token) {
  if (document.getElementById('lmReasonBox')) return;
  const reasonDiv = document.createElement('div');
  reasonDiv.id = 'lmReasonBox';
  reasonDiv.style.marginTop = '10px';

  const reasonInput = document.createElement('textarea');
  reasonInput.placeholder = 'Enter reason for rejection';
  reasonInput.rows = 3;
  reasonInput.style.width = '300px';
  reasonInput.style.marginRight = '10px';

  const submitBtn = document.createElement('button');
  submitBtn.textContent = 'Submit';
  submitBtn.onclick = () => {
    const reason = reasonInput.value.trim();
    if (!reason) return alert('Reason is required to reject.');
    lineManagerDecision(submissionId, 'not approved', token, reason);
  };

  const cancelBtn = document.createElement('button');
  cancelBtn.textContent = 'Cancel';
  cancelBtn.onclick = () => reasonDiv.remove();

  reasonDiv.appendChild(reasonInput);
  reasonDiv.appendChild(submitBtn);
  reasonDiv.appendChild(cancelBtn);
  actionsDiv.appendChild(reasonDiv);
}

async function lineManagerDecision(submissionId, action, token, reason = '') {
  try {
    const body = { token, action };
    if (reason) body.reason = reason;

    const res = await fetch(`/api/submissions/line-manager/action/${submissionId}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body)
    });

    const result = await res.json();
    if (!res.ok) {
      alert(result.message || "Action failed");
      return;
    }

    alert(`Submission ${action} successfully.`);
    location.reload();
  } catch (err) {
    console.error("Error sending decision:", err);
    alert("Error sending decision.");
  }
}

function generatePDF(sub) {
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF();
  let y = 20;

  doc.setFontSize(16);
  doc.text("Timesheet Report", 14, y);
  doc.setFontSize(11);
  y += 10;

  doc.text(`User: ${sub.user?.name || 'Unknown'} (${sub.user?.email || ''})`, 14, y);
  y += 6;
  doc.text(`Project: ${sub.project?.projectName || 'N/A'}`, 14, y);
  y += 6;
  doc.text(`Status: ${sub.status}`, 14, y);
  y += 6;
  doc.text(`Submitted At: ${new Date(sub.submittedAt).toLocaleString()}`, 14, y);
  y += 10;

  doc.text("Entries:", 14, y);
  y += 6;

  sub.entries.forEach(e => {
    doc.text(`${e.date} | ${e.day} | ${e.hours} hrs | ${e.notes || ''}`, 14, y);
    y += 6;
    if (y > 270) { doc.addPage(); y = 20; }
  });

  y += 10;
  doc.text(`Total Hours: ${sub.entries.reduce((a,b)=>a+(b.hours||0),0)}`, 14, y);

  doc.save(`Timesheet_${sub.user?.name || 'User'}.pdf`);
}