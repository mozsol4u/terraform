document.getElementById('forgotForm').addEventListener('submit', async function (e) {
  e.preventDefault();
  const email = document.getElementById('email').value;

  try {
    const res = await fetch('/api/users/forgot-password', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email })
    });

    const data = await res.json();
    document.getElementById('message').textContent = data.message;
  } catch (err) {
    document.getElementById('message').textContent = 'Error sending reset email.';
    console.error(err);
  }
});
