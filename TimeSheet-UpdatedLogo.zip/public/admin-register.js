document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('adminRegisterForm');
  const messageDiv = document.getElementById('message');

  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    const name = document.getElementById('name').value.trim();
    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value.trim();

    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, password, isAdmin: true })
      });

      const data = await res.json();

      if (res.ok) {
        messageDiv.textContent = 'Admin account created. Redirecting to login...';
        messageDiv.style.color = 'green';
        setTimeout(() => {
          window.location.href = 'timesheet.html';
        }, 2000);
      } else {
        messageDiv.textContent = data.message || 'Failed to create admin';
        messageDiv.style.color = 'red';
      }
    } catch (err) {
      console.error(err);
      messageDiv.textContent = 'Something went wrong';
      messageDiv.style.color = 'red';
    }
  });
});
