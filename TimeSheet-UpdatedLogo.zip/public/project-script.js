document.getElementById('projectForm').addEventListener('submit', async function (e) {
  e.preventDefault();

  const projectName = document.getElementById('projectName').value;
  const description = document.getElementById('description').value;
  const hoursWorked = document.getElementById('hoursWorked').value;
  const date = document.getElementById('date').value;

  const token = localStorage.getItem('token');
  if (!token) {
    alert('You must be logged in.');
    return;
  }

  const res = await fetch('/api/projects', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`
    },
    body: JSON.stringify({
      projectName,
      description,
      hoursWorked,
      date
    })
  });

  const data = await res.json();
  const messageDiv = document.getElementById('projectMessage');

  if (res.ok) {
    messageDiv.textContent = 'Project submitted successfully!';
    document.getElementById('projectForm').reset();
  } else {
    messageDiv.textContent = `Error: ${data.error || data.message}`;
  }
});
