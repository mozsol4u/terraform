document.getElementById('loginForm').addEventListener('submit', async (e) => {
  e.preventDefault();

  const email = document.getElementById('email').value;
  const password = document.getElementById('password').value;

  try {
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    });

    const data = await res.json();

    if (res.ok) {
      localStorage.setItem('token', data.token);
      localStorage.setItem('isAdmin', data.user.isAdmin);

      document.getElementById('message').textContent = 'Login successful!';

      if (data.user.isAdmin) {
        window.location.href = 'admin-dashboard.html';
      } else {
        window.location.href = 'dashboard.html';
      }

    } else {
      document.getElementById('message').textContent = `${data.message}`;
    }
  } catch (err) {
    document.getElementById('message').textContent = 'Network error';
  }
});
