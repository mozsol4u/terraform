const fs = require('fs');
require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const bodyParser = require('body-parser');
const path = require('path');
const cron = require('node-cron');

const authRoutes = require('./routes/auth');
const projectRoutes = require('./routes/projects');
const submissionRoutes = require('./routes/submissions');
const uploadRoutes = require('./routes/upload');
const userRoutes = require('./routes/users');

const Submission = require('./models/Submission');
const User = require('./models/User');
const sendEmail = require('./utils/sendEmail');

const app = express();
const PORT = process.env.PORT || 5000;

app.use((req, res, next) => {
  console.log(`${req.method} ${req.url}`);
  next();
});

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
const publicPath = path.join(__dirname, 'public');

app.get('/debug-files', (req, res) => {
    let files = [];

    try {
        files = fs.readdirSync(publicPath);
    } catch (error) {
        files = [`ERROR: ${error.message}`];
    }

    res.json({
        applicationDirectory: __dirname,
        publicDirectory: publicPath,
        publicExists: fs.existsSync(publicPath),
        files: files,
        timesheetExists: fs.existsSync(path.join(publicPath, 'timesheet.html')),
        stylesExists: fs.existsSync(path.join(publicPath, 'styles.css')),
        loginExists: fs.existsSync(path.join(publicPath, 'login.js')),
        logoExists: fs.existsSync(path.join(publicPath, 'logo.png')),
        forgotPasswordExists: fs.existsSync(
            path.join(publicPath, 'forgot-password.html')
        )
    });
});

app.use(express.static(publicPath));
app.use(express.static(path.join(__dirname, 'public')));



app.use('/api/auth', authRoutes);
app.use('/api/projects', projectRoutes);
app.use('/api/submissions', submissionRoutes);
app.use('/api/upload', uploadRoutes);
app.use('/api/users', userRoutes);

console.log("Submission routes mounted at /api/submissions");

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'timesheet.html'));
});

mongoose.connect(process.env.MONGO_URI)
  .then(() => {
    console.log('MongoDB connected');
    app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });

    cron.schedule('0 9 * * *', async () => {
      console.log('Running daily timesheet reminder check...');

      const today = new Date();
      const startOfDay = new Date(today.setHours(0, 0, 0, 0));

      try {
        const pendingSubmissions = await Submission.find({ isSubmitted: false }).populate('user project');

        for (const sub of pendingSubmissions) {
          if (!sub.dueDate) continue;

          const due = new Date(sub.dueDate);
          const diffDays = Math.floor((startOfDay - due) / (1000 * 60 * 60 * 24));

          if (diffDays === -1 || diffDays === 0 || diffDays > 0) {
            const userEmail = sub.user.email;
            const projectName = sub.project.projectName;

            await sendEmail(
              userEmail,
              `Reminder: Submit your ${projectName} timesheet`,
              `
                <p>Hello ${sub.user.name || 'there'},</p>
                <p>This is a reminder to submit your timesheet for <b>${projectName}</b>.</p>
                <p><b>Due Date:</b> ${due.toDateString()}</p>
                ${
                  diffDays > 0
                    ? `<p>Your timesheet is now <b>${diffDays}</b> day(s) overdue.</p>`
                    : `<p>Please make sure to submit it by the due date.</p>`
                }
                <p>Thanks</p>
              `
            );
            console.log(` Reminder sent to ${userEmail} for ${projectName}`);
          }
        }
      } catch (error) {
        console.error(' Error sending reminders:', error);
      }
    });

  })
  .catch((err) => {
    console.error('MongoDB connection error:', err);
  });
