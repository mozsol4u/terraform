const express = require('express');
const router = express.Router();
const multer = require('multer');
const Submission = require('../models/Submission');
const Project = require('../models/Project');
const { protect, isAdmin } = require('../middleware/authMiddleware');
const sendEmail = require('../utils/sendEmail');

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads/');
  },
  filename: function (req, file, cb) {
    const uniqueName = Date.now() + '-' + file.originalname;
    cb(null, uniqueName);
  }
});
const upload = multer({ storage });

router.post('/submit/:projectId', protect, upload.single('file'), async (req, res) => {
  try {
    const file = req.file;

    if (!file) {
      return res.status(400).json({ error: 'No file uploaded' });
    }

    const newSubmission = new Submission({
      user: req.user._id,
      project: req.params.projectId,
      file: {
        filename: file.filename,
        originalname: file.originalname
      },
      submittedAt: new Date(),
      status: 'pending',
      submissionType: 'file'
    });

    await newSubmission.save();

    res.status(201).json({ message: 'Submission successful', submission: newSubmission });
  } catch (err) {
    console.error('Error submitting timesheet:', err);
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

router.post('/submit-form/:projectId', protect, async (req, res) => {
  try {
    const { entries } = req.body;
    if (!Array.isArray(entries) || entries.length === 0) {
      return res.status(400).json({ message: 'Entries are required' });
    }

    for (const e of entries) {
      if (!e.date || typeof e.hours !== 'number') {
        return res.status(400).json({ message: 'Each entry must have a date and hours (number)' });
      }
    }

    const project = await Project.findById(req.params.projectId).lean();
    if (!project) return res.status(404).json({ message: 'Project not found' });

    const totalHours = entries.reduce((sum, e) => sum + (Number(e.hours) || 0), 0);

    const submission = await Submission.create({
      user: req.user._id,
      project: req.params.projectId,
      submissionType: 'form',
      entries,
      totalHours,
      status: 'pending',
      submittedAt: new Date()
    });

    if (project.lineManagerRequired && project.lineManagerEmail) {
      const subject = `Timesheet Submitted for "${project.projectName}"`;
      const html = `
        <p>Hello ${project.lineManagerName || ''},</p>
        <p>The employee has submitted a timesheet (form) for <strong>${project.projectName}</strong>.</p>
        <p>Total hours: <strong>${totalHours}</strong></p>
        <p>Please review it in the admin dashboard.</p>
        <p>Thanks</p>
      `;
      await sendEmail(project.lineManagerEmail, subject, html);
    }

    return res.status(201).json({ message: 'Form timesheet submitted', submission });
  } catch (err) {
    console.error('Error submitting form timesheet:', err);
    res.status(500).json({ message: 'Server error' });
  }
});

router.get('/', protect, isAdmin, async (req, res) => {
  try {
    const submissions = await Submission.find()
      .populate({ path: 'user', select: 'name email' })
      .populate({ path: 'project', select: 'projectName' })
      .lean();

    return res.json(submissions);
  } catch (err) {
    console.error('Error fetching submissions:', err);
    res.status(500).json({ message: 'Server error' });
  }
});

router.delete('/:id', protect, isAdmin, async (req, res) => {
  try {
    const submission = await Submission.findById(req.params.id);
    if (!submission) {
      return res.status(404).json({ message: 'Submission not found' });
    }
    await submission.deleteOne();
    res.json({ message: 'Submission deleted successfully' });
  } catch (err) {
    console.error('Error deleting submission:', err);
    res.status(500).json({ message: 'Server error' });
  }
});

router.get('/user', protect, async (req, res) => {
  try {
    const submissions = await Submission.find({ user: req.user._id })
      .populate({ path: 'project', select: 'projectName' })
      .lean();
    res.json(submissions);
  } catch (err) {
    console.error('Error fetching user submissions:', err);
    res.status(500).json({ message: 'Server error' });
  }
});

router.put('/submit/:id/approve', protect, isAdmin, async (req, res) => {
  try {
    const submission = await Submission.findById(req.params.id)
      .populate({ path: 'user', select: 'name email' })
      .populate({ path: 'project', select: 'projectName' });

    if (!submission) {
      return res.status(404).json({ message: 'Submission not found' });
    }

    submission.status = 'approved';
    await submission.save();

    const subject = `Your Timesheet for "${submission.project.projectName}" has been approved`;
    const html = `
      <p>Hi ${submission.user.name},</p>
      <p>Your timesheet for project <strong>${submission.project.projectName}</strong> has been <strong>approved</strong>.</p>
      <p>Thanks</p>
    `;
    await sendEmail(submission.user.email, subject, html);

    res.json({ message: 'Submission approved and email sent' });
  } catch (err) {
    console.error('Error approving submission:', err);
    res.status(500).json({ message: 'Server error' });
  }
});

router.put('/submit/:id/reject', protect, isAdmin, async (req, res) => {
  try {
    const submission = await Submission.findById(req.params.id)
      .populate({ path: 'user', select: 'name email' })
      .populate({ path: 'project', select: 'projectName' });

    if (!submission) {
      return res.status(404).json({ message: 'Submission not found' });
    }

    submission.status = 'not approved';
    submission.decisionNotes = req.body.reason || '';
    await submission.save();

    const subject = `Your Timesheet for "${submission.project.projectName}" was not approved`;
    const html = `
      <p>Hi ${submission.user.name},</p>
      <p>Your timesheet for project <strong>${submission.project.projectName}</strong> has been <strong>not approved</strong>.</p>
      ${submission.decisionNotes ? `<p>Reason: ${submission.decisionNotes}</p>` : ''}
      <p>Please reach out to your project manager if you have questions.</p>
      <p>Thanks</p>
    `;
    await sendEmail(submission.user.email, subject, html);

    res.json({ message: 'Submission rejected and email sent' });
  } catch (err) {
    console.error('Error rejecting submission:', err);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;
