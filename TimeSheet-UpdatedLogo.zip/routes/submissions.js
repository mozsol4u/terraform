const express = require('express');
const router = express.Router();
const multer = require('multer');
const crypto = require("crypto");
const Submission = require('../models/Submission');
const Project = require('../models/Project');
const { protect, isAdmin } = require('../middleware/authMiddleware');
const sendEmail = require('../utils/sendEmail');
const path = require('path');
const PDFDocument = require('pdfkit');
const fs = require('fs');

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads/');
  },
  filename: function (req, file, cb) {
    const uniqueName = Date.now() + '-' + file.originalname;
    cb(null, uniqueName);
  }
});
const upload = multer({ storage });

router.get('/public/view-form/:submissionId', async (req, res) => {
  try {
    res.sendFile(path.join(__dirname, '../public/form-viewer.html'));
  } catch (err) {
    res.status(500).json({ message: 'Server error' });
  }
});

router.post('/:id/notify', protect, async (req, res) => {
  try {
    const submission = await Submission.findById(req.params.id)
      .populate('user')
      .populate('project');

    if (!submission) {
      return res.status(404).json({ message: 'Submission not found' });
    }

    const managerEmail = submission.project?.managerEmail;
    if (!managerEmail) {
      return res.status(400).json({ message: 'No manager email set for this project' });
    }

    const subject = `Timesheet Submitted: ${submission.project.projectName}`;
    const message = `
      Hello,

      A new timesheet has been submitted.

      User: ${submission.user?.name} (${submission.user?.email})
      Project: ${submission.project?.projectName}
      Submitted At: ${new Date(submission.submittedAt).toLocaleString()}

      Please log in to review it.
    `;

    await sendEmail(managerEmail, subject, message);

    res.json({ message: 'Notification email sent to line manager' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Error sending email' });
  }
});

router.post('/download-pdf', async (req, res) => {
  try {
    const jsonData = req.body;

    const doc = new PDFDocument();
    const fileName = `timesheet_${Date.now()}.pdf`;
    const filePath = path.join(__dirname, '../uploads', fileName);

    const writeStream = fs.createWriteStream(filePath);
    doc.pipe(writeStream);

    doc.fontSize(20).text('Timesheet Report', { align: 'center' });
    doc.moveDown();

    doc.fontSize(12)
      .text(`User: ${jsonData.user}`)
      .text(`Project: ${jsonData.project}`)
      .text(`Period: ${jsonData.period}`)
      .moveDown();

    doc.fontSize(14).text('Entries:', { underline: true });
    doc.moveDown();

    jsonData.entries.forEach(entry => {
      doc.fontSize(12)
        .text(`Date: ${entry.date}`)
        .text(`Hours: ${entry.hours}`)
        .text(`Task: ${entry.task}`)
        .moveDown();
    });

    doc.end();

    writeStream.on('finish', () => {
      res.download(filePath, fileName, err => {
        if (err) console.error('Error sending PDF:', err);
        fs.unlinkSync(filePath);
      });
    });
  } catch (err) {
    console.error('Error generating PDF:', err);
    res.status(500).json({ message: 'Error generating PDF' });
  }
});

router.post('/submit/:projectId', protect, upload.single('file'), async (req, res) => {
  try {
    const project = await Project.findById(req.params.projectId);
    if (!project) {
      return res.status(404).json({ error: "Project not found" });
    }

    const dueDate = new Date(project.endDate);

    const submissionData = {
      project: project._id,
      user: req.user._id,
      lineManagerRequired: project.lineManagerRequired || false,
      dueDate,
      submittedAt: new Date(),
      isSubmitted: true,
      status: "pending"
    };

    if (req.file) {
      submissionData.file = {
        filename: req.file.filename,
        originalname: req.file.originalname
      };
      submissionData.submissionType = "file";
    } else if (req.body.entries) {
      submissionData.entries =
        typeof req.body.entries === "string"
          ? JSON.parse(req.body.entries)
          : req.body.entries;

      submissionData.submissionType = "form";
    } else {
      return res.status(400).json({
        error: "No file or form entries provided."
      });
    }

    if (submissionData.lineManagerRequired) {
      submissionData.lineManagerToken = crypto.randomBytes(20).toString("hex");
    }

    const submission = new Submission(submissionData);
    await submission.save();

    if (submissionData.lineManagerRequired && project.lineManagerEmail) {
      const link = `http://localhost:5000/form-viewer.html?submissionId=${submission._id}&token=${submission.lineManagerToken}`;

      await sendEmail(
        project.lineManagerEmail,
        "Timesheet requires your approval",
        `A timesheet was submitted and requires your review. Open: ${link}`,
        `<p>A timesheet was submitted and requires your review. <a href="${link}">View Timesheet</a></p>`
      );
    }

    res.status(201).json(submission);

  } catch (err) {
    console.error("Error saving submission:", err);
    res.status(500).json({ message: "Error saving submission" });
  }
});

router.get('/public/form-viewer/:submissionId', async (req, res) => {
  try {
    const submission = await Submission.findById(req.params.submissionId)
      .populate({ path: 'user', select: 'name email' })
      .populate({ path: 'project', select: 'projectName lineManagerRequired lineManagerEmail' })
      .lean();

    if (!submission) return res.status(404).json({ message: 'Submission not found' });

    const token = req.query.token;
    const tokenValid = submission.lineManagerRequired && token && submission.lineManagerToken === token;

    res.json({
      ...submission,
      lineManagerRequired: submission.lineManagerRequired === true,
      tokenValid
    });
  } catch (err) {
    console.error('Error fetching submission:', err);
    res.status(500).json({ message: 'Server error' });
  }
});

router.put('/public/form-viewer/:submissionId/approve', async (req, res) => {
  try {
    const { submissionId } = req.params;

    const submission = await Submission.findById(submissionId)
      .populate({ path: 'user', select: 'name email' })
      .populate({ path: 'project', select: 'projectName lineManagerRequired lineManagerName lineManagerEmail' });

    if (!submission) return res.status(404).json({ message: 'Submission not found' });

    submission.status = 'approved';
    await submission.save();

    if (submission.user && submission.user.email) {
      await sendEmail(
        submission.user.email,
        `Your Timesheet for "${submission.project?.projectName || ''}" has been approved`,
        `Hi ${submission.user.name || ''},\n\nYour timesheet for project "${submission.project?.projectName || ''}" has been approved.\n\nThanks,\nTimesheet App`
      );
    }

    return res.json({ message: 'Submission approved' });
  } catch (err) {
    console.error('Error in public approve:', err);
    return res.status(500).json({ message: 'Server error' });
  }
});

router.put('/public/form-viewer/:submissionId/reject', async (req, res) => {
  try {
    const { submissionId } = req.params;
    const { reason } = req.body || {};

    const submission = await Submission.findById(submissionId)
      .populate({ path: 'user', select: 'name email' })
      .populate({ path: 'project', select: 'projectName lineManagerRequired lineManagerName lineManagerEmail' });

    if (!submission) return res.status(404).json({ message: 'Submission not found' });

    submission.status = 'not approved';
    submission.decisionNotes = reason || '';
    await submission.save();

    if (submission.user && submission.user.email) {
      await sendEmail(
        submission.user.email,
        `Your Timesheet for "${submission.project?.projectName || ''}" was not approved`,
        `Hi ${submission.user.name || ''},\n\nYour timesheet for project "${submission.project?.projectName || ''}" was not approved.\n${reason ? 'Reason: ' + reason : ''}\n\nThanks`
      );
    }

    return res.json({ message: 'Submission rejected' });
  } catch (err) {
    console.error('Error in public reject:', err);
    return res.status(500).json({ message: 'Server error' });
  }
});


router.post('/line-manager/action/:submissionId', async (req, res) => {
  try {
    const { token, action, reason } = req.body;

    if (!token || !action) {
      return res.status(400).json({ message: "Token and action are required" });
    }

    if (action === "not approved" && (!reason || reason.trim() === "")) {
      return res.status(400).json({ message: "Reason is required when rejecting" });
    }

    const submission = await Submission.findById(req.params.submissionId)
      .populate('user', 'name email')
      .populate('project', 'projectName');

    if (!submission || submission.lineManagerToken !== token) {
      return res.status(403).json({ message: "Invalid token" });
    }

    if (action === "approved") {
      submission.status = "approved";
      submission.reason = undefined;
    } else {
      submission.status = "not approved";
      submission.reason = reason;
    }

    await submission.save();

    if (submission.user?.email) {
      if (action === "approved") {
        await sendEmail(
          submission.user.email,
          `Timesheet Approved`,
          `Hi ${submission.user.name}, your timesheet for project "${submission.project?.projectName}" has been approved.`,
          `<p>Hi ${submission.user.name},</p><p>Your timesheet for project "<strong>${submission.project?.projectName}</strong>" has been approved.</p>`
        );
      } else {
        await sendEmail(
          submission.user.email,
          `Timesheet Not Approved`,
          `Hi ${submission.user.name}, your timesheet for project "${submission.project?.projectName}" was not approved. Reason: ${reason}`,
          `<p>Hi ${submission.user.name},</p><p>Your timesheet for project "<strong>${submission.project?.projectName}</strong>" was not approved.</p><p>Reason: ${reason}</p>`
        );
      }
    }

    res.json({ message: `Submission ${submission.status}` });
  } catch (err) {
    console.error("LM action error:", err);
    res.status(500).json({ message: "Error processing action" });
  }
});
router.get('/draft/:projectId', protect, async (req, res) => {
  try {
    const draft = await Submission.findOne({
      user: req.user.id,
      project: req.params.projectId,
      status: 'draft',
      submissionType: 'form'
    });

    if (!draft) return res.json(null);
    res.json(draft);
  } catch (err) {
    console.error('Error fetching draft:', err);
    res.status(500).json({ message: 'Error fetching draft' });
  }
});


router.post('/save/:projectId', protect, async (req, res) => {
  try {
    const { projectId } = req.params;
    const { entries } = req.body;

    if (!entries || entries.length === 0) {
      return res.status(400).json({ message: 'No timesheet data to save.' });
    }

    let draft = await Submission.findOne({ 
      project: projectId, 
      user: req.user._id, 
      status: 'draft' 
    });

    if (draft) {
      draft.entries = entries;
      draft.submissionType = 'form';
      await draft.save();
    } else {
      draft = new Submission({
        project: projectId,
        user: req.user._id,
        entries,
        status: 'draft',
        submissionType: 'form',
      });
      await draft.save();
    }

    res.json({ message: 'Draft saved successfully', draft });
  } catch (error) {
    console.error('Error saving draft:', error);
    res.status(500).json({ message: 'Error saving draft', error: error.message });
  }
});

router.get('/user', protect, async (req, res) => {
  try {
    const submissions = await Submission.find({ user: req.user._id })
      .populate({ path: 'project', select: 'projectName' })
      .lean();
    res.json(submissions);
  } catch (err) {
    console.error('Error fetching user submissions:', err);
    res.status(500).json({ message: 'Server error' });
  }
});

router.get('/project/:projectId', protect, async (req, res) => {
  try {
    const submissions = await Submission.find({
      user: req.user._id,
      project: req.params.projectId
    })
      .populate({ path: 'project', select: 'projectName period' })
      .sort({ submittedAt: -1 })
      .lean();
    res.json(submissions);
  } catch (err) {
    console.error('Error fetching project submissions:', err);
    res.status(500).json({ message: 'Server error' });
  }
});
router.put('/mine/:id', protect, async (req, res) => {
  try {
    const { entries } = req.body;

    if (!Array.isArray(entries) || entries.length === 0) {
      return res.status(400).json({ message: 'Entries are required.' });
    }

    for (const e of entries) {
      const hours = Number(e.hours);
      if (Number.isNaN(hours) || hours < 0 || hours > 24) {
        return res.status(400).json({ message: 'Each entry must have hours between 0 and 24.' });
      }
    }

    const submission = await Submission.findById(req.params.id);
    if (!submission) return res.status(404).json({ message: 'Submission not found' });

    if (submission.user.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: 'You can only edit your own timesheets.' });
    }

    if (submission.submissionType !== 'form') {
      return res.status(400).json({ message: 'Only form-based submissions can be edited.' });
    }

    submission.entries = entries.map(e => ({
      date: e.date,
      day: e.day,
      hours: Number(e.hours),
      notes: e.notes || ''
    }));

    if (submission.status === 'approved' || submission.status === 'not approved') {
      submission.status = 'pending';
      submission.submittedAt = new Date();
    }

    submission.adminEdited = false;
    submission.adminEditNote = undefined;

    await submission.save();

    res.json({ message: 'Timesheet updated successfully', submission });
  } catch (err) {
    console.error('Error editing own submission:', err);
    res.status(500).json({ message: 'Server error' });
  }
});

router.put('/:id/entries', protect, isAdmin, async (req, res) => {
  try {
    const { entries, note } = req.body;

    if (!Array.isArray(entries) || entries.length === 0) {
      return res.status(400).json({ message: 'Entries are required.' });
    }

    if (!note || !note.trim()) {
      return res.status(400).json({ message: 'A note explaining the change is required for the employee.' });
    }

    for (const e of entries) {
      const hours = Number(e.hours);
      if (Number.isNaN(hours) || hours < 0 || hours > 24) {
        return res.status(400).json({ message: 'Each entry must have hours between 0 and 24.' });
      }
    }

    const submission = await Submission.findById(req.params.id)
      .populate('user', 'name email')
      .populate('project', 'projectName');

    if (!submission) return res.status(404).json({ message: 'Submission not found' });
    if (submission.submissionType !== 'form') {
      return res.status(400).json({ message: 'Only form-based submissions can have hours edited.' });
    }

    submission.entries = entries.map(e => ({
      date: e.date,
      day: e.day,
      hours: Number(e.hours),
      notes: e.notes || ''
    }));
    submission.adminEdited = true;
    submission.adminEditNote = note.trim();
    submission.editedBy = req.user._id;
    submission.editedAt = new Date();

    await submission.save();

    if (submission.user?.email) {
      const totalHours = submission.entries.reduce((sum, e) => sum + (Number(e.hours) || 0), 0);
      try {
        await sendEmail(
          submission.user.email,
          `Your Timesheet for "${submission.project?.projectName || ''}" was updated`,
          `Hi ${submission.user.name || ''}, an admin corrected the hours on your timesheet for "${submission.project?.projectName || ''}". New total: ${totalHours}.\n\nNote from admin: ${submission.adminEditNote}`,
          `<p>Hi ${submission.user.name || ''},</p><p>An administrator corrected the hours on your timesheet for "<strong>${submission.project?.projectName || ''}</strong>".</p><p>New total hours: <strong>${totalHours}</strong></p><p><strong>Note from admin:</strong> ${submission.adminEditNote}</p>`
        );
      } catch (emailErr) {
        console.error('Error sending edit notification email:', emailErr);
      }
    }

    res.json({ message: 'Entries updated successfully', submission });
  } catch (err) {
    console.error('Error editing submission entries:', err);
    res.status(500).json({ message: 'Server error' });
  }
});

router.get('/:id', protect, isAdmin, async (req, res) => { /* ... */ });
router.get('/', protect, isAdmin, async (req, res) => {
  try {
    const submissions = await Submission.find()
      .populate({ path: 'user', select: 'name email' })
      .populate({ path: 'project', select: 'projectName lineManagerRequired' })
      .lean();

    res.json(submissions);
  } catch (err) {
    console.error('Error fetching admin submissions:', err);
    res.status(500).json({ message: 'Error fetching submissions' });
  }
});
router.delete('/:id', protect, isAdmin, async (req, res) => {
  try {
    const submission = await Submission.findById(req.params.id);
    if (!submission) return res.status(404).json({ message: 'Submission not found' });

    await submission.deleteOne();
    res.json({ message: 'Submission deleted successfully' });
  } catch (err) {
    console.error('Error deleting submission:', err);
    res.status(500).json({ message: 'Error deleting submission' });
  }
});

router.put('/submit/:id/approve', protect, isAdmin, async (req, res) => {
  try {
    const submission = await Submission.findById(req.params.id)
      .populate('user', 'name email')
      .populate('project', 'projectName lineManagerRequired');
    if (!submission) return res.status(404).json({ message: 'Submission not found' });

    const lmRequired = submission.lineManagerRequired || submission.project?.lineManagerRequired;
    if (lmRequired) {
      return res.status(403).json({
        message: 'This project requires line manager approval. Only the line manager can approve or reject this timesheet.'
      });
    }

    submission.status = 'approved';
    await submission.save();

    if (submission.user?.email) {
      await sendEmail(
        submission.user.email,
        'Timesheet Approved',
        `Hi ${submission.user.name}, your timesheet for project "${submission.project?.projectName}" has been approved.`,
        `<p>Hi ${submission.user.name},</p>
         <p>Your timesheet for project "<strong>${submission.project?.projectName}</strong>" has been approved.</p>`
      );
    }

    res.json({ message: 'Submission approved', submission });
  } catch (err) {
    console.error('Error approving submission:', err);
    res.status(500).json({ message: 'Error approving submission' });
  }
});

router.put('/submit/:id/reject', protect, isAdmin, async (req, res) => {
  try {
    const { reason } = req.body;
    const submission = await Submission.findById(req.params.id)
      .populate('user', 'name email')
      .populate('project', 'projectName lineManagerRequired');
    if (!submission) return res.status(404).json({ message: 'Submission not found' });

    const lmRequired = submission.lineManagerRequired || submission.project?.lineManagerRequired;
    if (lmRequired) {
      return res.status(403).json({
        message: 'This project requires line manager approval. Only the line manager can approve or reject this timesheet.'
      });
    }

    submission.status = 'not approved';
    submission.rejectionReason = reason || '';
    submission.decisionNotes = reason || '';
    await submission.save();

    if (submission.user?.email) {
      await sendEmail(
        submission.user.email,
        'Timesheet Not Approved',
        `Hi ${submission.user.name}, your timesheet for project "${submission.project?.projectName}" was not approved. Reason: ${reason}`,
        `<p>Hi ${submission.user.name},</p>
         <p>Your timesheet for project "<strong>${submission.project?.projectName}</strong>" was <strong>not approved</strong>.</p>
         <p><strong>Reason:</strong> ${reason}</p>`
      );
    }

    res.json({ message: 'Submission rejected', submission });
  } catch (err) {
    console.error('Error rejecting submission:', err);
    res.status(500).json({ message: 'Error rejecting submission' });
  }
});


module.exports = router;