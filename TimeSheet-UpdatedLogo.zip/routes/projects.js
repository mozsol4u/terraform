const express = require('express');
const router = express.Router();
const path = require('path');
const multer = require('multer');

const Project = require('../models/Project');
const User = require('../models/User');
const { protect, isAdmin } = require('../middleware/authMiddleware');
const sendEmail = require('../utils/sendEmail');

const uploadPath = path.join(__dirname, '..', 'uploads');
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadPath),
  filename: (req, file, cb) => cb(null, Date.now() + '-' + file.originalname),
});
const upload = multer({ storage });

const toBool = (v) => {
  if (typeof v === 'boolean') return v;
  if (typeof v === 'number') return v !== 0;
  if (typeof v === 'string') {
    const s = v.trim().toLowerCase();
    return ['true', '1', 'yes', 'on'].includes(s);
  }
  return false;
};

function mapTimesheetForm(timesheetForm) {
  switch ((timesheetForm || '').toLowerCase()) {
    case 'weekly':
    case 'biweekly':
    case 'monthly':
    case 'semimonthly':
      return { timesheetType: 'form', period: timesheetForm.toLowerCase() };
    default:
      throw new Error(
        'Invalid timesheet type. Use one of: "weekly", "biweekly", "monthly", "semimonthly".'
      );
  }
}

router.post('/assign', protect, isAdmin, async (req, res) => {
  try {
    const {
      userId,
      projectName,
      startDate,
      endDate,
      timesheetForm,
      lineManagerRequired,
      lineManagerName,
      lineManagerEmail,
      replaceExisting,
    } = req.body;

    if (!userId || !projectName || !startDate || !endDate || !timesheetForm) {
      return res.status(400).json({
        error: 'Missing required fields (userId, projectName, startDate, endDate, timesheetForm).',
      });
    }

    const assignedUser = await User.findById(userId);
    if (!assignedUser) {
      return res.status(404).json({ error: 'User not found' });
    }

    const existingProject = await Project.findOne({ assignedTo: userId }).lean();
    if (existingProject) {
      if (!toBool(replaceExisting)) {
        return res.status(409).json({
          error: `${assignedUser.name || 'This user'} already has a project assigned ("${existingProject.projectName}"). Remove or replace it before assigning a new one.`,
          existingProject,
        });
      }
      await Project.deleteOne({ _id: existingProject._id });
    }

    let timesheetType, period;
    try {
      ({ timesheetType, period } = mapTimesheetForm(timesheetForm));
    } catch (e) {
      return res.status(400).json({ error: e.message });
    }

    const lmRequired = toBool(lineManagerRequired);

    if (lmRequired && !lineManagerEmail) {
      return res.status(400).json({ error: 'Line Manager Email is required when approval is required.' });
    }

    const project = await Project.create({
      projectName,
      assignedTo: assignedUser._id,
      assignedBy: req.user._id,
      startDate,
      endDate,
      timesheetType,
      period,
      lineManagerRequired: lmRequired,
      lineManagerName: lmRequired ? lineManagerName : undefined,
      lineManagerEmail: lmRequired ? lineManagerEmail : undefined,
    });

    try {
      await sendEmail(
        assignedUser.email,
        'New Assignment',
        `
          Hi ${assignedUser.name || 'there'},
          You have been assigned to the project: ${projectName}.
          Submission type: (${period})
          Start: ${new Date(startDate).toLocaleDateString()}
          End: ${new Date(endDate).toLocaleDateString()}
          Please log in to your dashboard to submit your timesheets.
        `
      );
    } catch (emailErr) {
      console.error('Error sending email to employee:', emailErr);

    }


    if (lmRequired && lineManagerEmail) {
      try {
        await sendEmail(
          lineManagerEmail,
          `New Project Assigned: ${projectName}`,
          `
            Hello ${lineManagerName || 'Line Manager'},
            You have been designated as the line manager for the project ${projectName}.
            The employee ${assignedUser.name || assignedUser.email} will submit timesheets for your review.
              Timesheet type: Form (${period})
              Start: ${new Date(startDate).toLocaleDateString()}
              End: ${new Date(endDate).toLocaleDateString()}
            You will receive notifications when a timesheet is submitted.
            — Timesheet System
          `
        );
      } catch (emailErr) {
        console.error('Error sending email to line manager:', emailErr);
      }
    }

    return res.status(201).json({ message: 'Project assigned successfully', project });
  } catch (err) {
    console.error('Error assigning project:', err);
    return res.status(500).json({ error: 'Server error' });
  }
});

router.get('/user', protect, async (req, res) => {
  try {
    const projects = await Project.find({ assignedTo: req.user._id }).lean();
    return res.json(projects);
  } catch (err) {
    console.error('Error fetching projects:', err);
    return res.status(500).json({ error: 'Server error' });
  }
});

router.get('/all-users', protect, async (req, res) => {
  try {
    const users = await User.find({ isAdmin: false }, { name: 1, email: 1 });
    return res.json(users);
  } catch (err) {
    console.error('Failed to fetch users:', err);
    return res.status(500).json({ error: 'Failed to fetch users' });
  }
});

router.get('/by-user/:userId', protect, isAdmin, async (req, res) => {
  try {
    const project = await Project.findOne({ assignedTo: req.params.userId }).lean();
    return res.json(project || null);
  } catch (err) {
    console.error('Error fetching project for user:', err);
    return res.status(500).json({ error: 'Server error' });
  }
});

router.delete('/:projectId', protect, isAdmin, async (req, res) => {
  try {
    const project = await Project.findByIdAndDelete(req.params.projectId);
    if (!project) return res.status(404).json({ error: 'Project not found' });
    return res.json({ message: 'Project unassigned successfully' });
  } catch (err) {
    console.error('Error unassigning project:', err);
    return res.status(500).json({ error: 'Server error' });
  }
});

router.get('/:projectId', protect, async (req, res) => {
  try {
    const project = await Project.findById(req.params.projectId).lean();
    if (!project) return res.status(404).json({ message: 'Project not found' });
    return res.json(project);
  } catch (err) {
    console.error('Error fetching project by ID:', err);
    return res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;